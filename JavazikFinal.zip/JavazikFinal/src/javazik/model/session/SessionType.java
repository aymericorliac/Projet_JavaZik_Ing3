package javazik.model.session;

public enum SessionType {
    AUCUNE,
    VISITEUR,
    ABONNE,
    ADMIN
}
