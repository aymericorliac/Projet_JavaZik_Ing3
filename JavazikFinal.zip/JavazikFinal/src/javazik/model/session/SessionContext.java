package javazik.model.session;

import javazik.model.user.Abonne;
import javazik.model.user.Administrateur;
import javazik.model.user.Utilisateur;

public class SessionContext {
    private SessionType type;
    private Utilisateur utilisateurCourant;
    private int ecoutesRestantesVisiteur;

    public SessionContext() {
        logout();
    }

    public SessionType getType() { return type; }
    public Utilisateur getUtilisateurCourant() { return utilisateurCourant; }
    public int getEcoutesRestantesVisiteur() { return ecoutesRestantesVisiteur; }

    public void demarrerVisiteur() {
        this.type = SessionType.VISITEUR;
        this.utilisateurCourant = null;
        this.ecoutesRestantesVisiteur = 5;
    }

    public void connecter(Utilisateur utilisateur) {
        this.utilisateurCourant = utilisateur;
        if (utilisateur instanceof Administrateur) this.type = SessionType.ADMIN;
        else if (utilisateur instanceof Abonne) this.type = SessionType.ABONNE;
        else this.type = SessionType.AUCUNE;
        this.ecoutesRestantesVisiteur = 0;
    }

    public void logout() {
        this.type = SessionType.AUCUNE;
        this.utilisateurCourant = null;
        this.ecoutesRestantesVisiteur = 0;
    }

    public boolean consommerEcouteVisiteur() {
        if (type == SessionType.VISITEUR && ecoutesRestantesVisiteur > 0) {
            ecoutesRestantesVisiteur--;
            return true;
        }
        return false;
    }

    public boolean estVisiteur() { return type == SessionType.VISITEUR; }
    public boolean estAbonne() { return type == SessionType.ABONNE; }
    public boolean estAdmin() { return type == SessionType.ADMIN; }
    public Abonne getAbonne() { return utilisateurCourant instanceof Abonne a ? a : null; }
    public Administrateur getAdmin() { return utilisateurCourant instanceof Administrateur a ? a : null; }

    @Override
    public String toString() {
        return switch (type) {
            case AUCUNE -> "Aucune session";
            case VISITEUR -> "Visiteur (" + ecoutesRestantesVisiteur + " écoute(s) restante(s))";
            case ABONNE -> "Abonné - " + utilisateurCourant.getNomAffichage();
            case ADMIN -> "Administrateur - " + utilisateurCourant.getNomAffichage();
        };
    }
}
