package javazik.model.user;

import javazik.model.media.Genre;
import javazik.model.media.Morceau;
import javazik.model.playlist.Playlist;

import java.io.Serial;
import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Utilisateur abonné pouvant gérer des playlists et un historique d'écoute.
 */
public class Abonne extends Utilisateur {
    @Serial
    private static final long serialVersionUID = 1L;

    private final List<Playlist> playlists;
    private final List<Morceau> historiqueEcoutes;

    public Abonne(String identifiant, String motDePasse, String nomAffichage) {
        super(identifiant, motDePasse, nomAffichage);
        this.playlists = new ArrayList<>();
        this.historiqueEcoutes = new ArrayList<>();
    }

    @Override
    public String getRole() { return "Abonné"; }

    public List<Playlist> getPlaylists() { return Collections.unmodifiableList(playlists); }
    public List<Morceau> getHistoriqueEcoutes() { return Collections.unmodifiableList(historiqueEcoutes); }

    public Playlist creerPlaylist(String nom) {
        Playlist playlist = new Playlist(nom, getIdentifiant());
        playlists.add(playlist);
        return playlist;
    }

    public boolean supprimerPlaylist(Playlist playlist) {
        return playlists.remove(playlist);
    }

    public void enregistrerEcoute(Morceau morceau) {
        if (morceau != null) {
            historiqueEcoutes.add(morceau);
        }
    }

    public Genre determinerGenreFavori() {
        if (historiqueEcoutes.isEmpty()) {
            return null;
        }
        Map<Genre, Integer> compteur = new EnumMap<>(Genre.class);
        for (Morceau morceau : historiqueEcoutes) {
            compteur.merge(morceau.getGenre(), 1, Integer::sum);
        }
        return compteur.entrySet().stream()
                .max(Map.Entry.comparingByValue())
                .map(Map.Entry::getKey)
                .orElse(null);
    }

    public String determinerInterpreteFavori() {
        return historiqueEcoutes.stream()
                .collect(java.util.stream.Collectors.groupingBy(m -> m.getInterprete().getNom(), LinkedHashMap::new, java.util.stream.Collectors.counting()))
                .entrySet()
                .stream()
                .max(Map.Entry.comparingByValue())
                .map(Map.Entry::getKey)
                .orElse(null);
    }

    public void nettoyerReferencesMorceau(Morceau morceau) {
        historiqueEcoutes.removeIf(m -> m.equals(morceau));
        for (Playlist playlist : playlists) {
            playlist.retirerMorceau(morceau);
        }
    }

    public Playlist getPlaylistParId(String id) {
        return playlists.stream().filter(p -> p.getId().equals(id)).findFirst().orElse(null);
    }
}
