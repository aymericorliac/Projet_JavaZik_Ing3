package javazik.model.user;

import java.io.Serial;
import java.io.Serializable;
import java.util.Objects;
import java.util.UUID;

public abstract class Utilisateur implements Serializable {
    @Serial
    private static final long serialVersionUID = 1L;

    private final String id;
    private final String identifiant;
    private String motDePasse;
    private String nomAffichage;
    private StatutCompte statut;

    protected Utilisateur(String identifiant, String motDePasse, String nomAffichage) {
        this.id = UUID.randomUUID().toString();
        this.identifiant = Objects.requireNonNull(identifiant).trim();
        this.motDePasse = Objects.requireNonNull(motDePasse);
        this.nomAffichage = Objects.requireNonNull(nomAffichage).trim();
        this.statut = StatutCompte.ACTIF;
    }

    public String getId() { return id; }
    public String getIdentifiant() { return identifiant; }
    public String getNomAffichage() { return nomAffichage; }
    public void setNomAffichage(String nomAffichage) { this.nomAffichage = Objects.requireNonNull(nomAffichage).trim(); }
    public boolean verifieMotDePasse(String motDePasse) { return this.motDePasse.equals(motDePasse); }
    public void changerMotDePasse(String nouveauMotDePasse) { this.motDePasse = Objects.requireNonNull(nouveauMotDePasse); }
    public StatutCompte getStatut() { return statut; }
    public boolean estActif() { return statut == StatutCompte.ACTIF; }
    public void suspendre() { this.statut = StatutCompte.SUSPENDU; }
    public void reactiver() { this.statut = StatutCompte.ACTIF; }

    public abstract String getRole();

    @Override
    public String toString() {
        return getRole() + " - " + identifiant + " (" + nomAffichage + ", " + statut + ")";
    }
}
