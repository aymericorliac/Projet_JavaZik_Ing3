package javazik.model.user;

import java.io.Serial;

public class Administrateur extends Utilisateur {
    @Serial
    private static final long serialVersionUID = 1L;

    public Administrateur(String identifiant, String motDePasse, String nomAffichage) {
        super(identifiant, motDePasse, nomAffichage);
    }

    @Override
    public String getRole() { return "Administrateur"; }
}
