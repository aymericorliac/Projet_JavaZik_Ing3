package javazik.model;

/**
 * Contrat pour les éléments pouvant être "joués" dans l'application.
 */
public interface Playable {
    String getPlayLabel();
    int getDureeSecondes();
}
