package javazik.model.review;

import java.io.Serial;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Objects;

public class AvisMorceau implements Serializable {
    @Serial
    private static final long serialVersionUID = 1L;

    private final String auteurIdentifiant;
    private int note;
    private String commentaire;
    private LocalDateTime derniereMiseAJour;

    public AvisMorceau(String auteurIdentifiant, int note, String commentaire) {
        this.auteurIdentifiant = Objects.requireNonNull(auteurIdentifiant);
        this.note = note;
        this.commentaire = commentaire == null ? "" : commentaire.trim();
        this.derniereMiseAJour = LocalDateTime.now();
    }

    public String getAuteurIdentifiant() { return auteurIdentifiant; }
    public int getNote() { return note; }
    public String getCommentaire() { return commentaire; }
    public LocalDateTime getDerniereMiseAJour() { return derniereMiseAJour; }

    public void mettreAJour(int note, String commentaire) {
        this.note = note;
        this.commentaire = commentaire == null ? "" : commentaire.trim();
        this.derniereMiseAJour = LocalDateTime.now();
    }

    @Override
    public String toString() {
        return auteurIdentifiant + " - " + note + "/5"
                + (commentaire == null || commentaire.isBlank() ? "" : " : " + commentaire);
    }
}
