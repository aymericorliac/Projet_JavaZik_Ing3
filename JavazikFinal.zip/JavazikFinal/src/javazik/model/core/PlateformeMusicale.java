package javazik.model.core;

import javazik.exception.AuthenticationException;
import javazik.exception.DuplicateItemException;
import javazik.exception.LimitEcoutesException;
import javazik.exception.NotFoundException;
import javazik.exception.PermissionException;
import javazik.exception.ValidationException;
import javazik.model.media.Album;
import javazik.model.media.Artiste;
import javazik.model.media.EntiteArtistique;
import javazik.model.media.Genre;
import javazik.model.media.Groupe;
import javazik.model.media.Morceau;
import javazik.model.media.SongSortMode;
import javazik.model.playlist.Playlist;
import javazik.model.session.SessionContext;
import javazik.model.user.Abonne;
import javazik.model.user.Administrateur;
import javazik.model.user.Utilisateur;

import java.io.Serial;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Service métier principal de Javazik.
 *
 * <p>Cette classe centralise les règles de gestion du catalogue, des comptes,
 * des playlists, des avis et des statistiques. Elle constitue le cœur du modèle
 * MVC et ne dépend d'aucune vue.</p>
 */
public class PlateformeMusicale implements Serializable {
    @Serial
    private static final long serialVersionUID = 1L;

    private final Catalogue catalogue;
    private final Map<String, Utilisateur> utilisateursParIdentifiant;
    private long ecoutesTotales;

    public PlateformeMusicale() {
        this.catalogue = new Catalogue();
        this.utilisateursParIdentifiant = new LinkedHashMap<>();
        this.ecoutesTotales = 0;
    }

    public Catalogue getCatalogue() { return catalogue; }
    public List<Utilisateur> getUtilisateurs() { return new ArrayList<>(utilisateursParIdentifiant.values()); }
    public long getEcoutesTotales() {
        return catalogue.getMorceaux().stream().mapToLong(Morceau::getNombreEcoutes).sum();
    }

    public void ajouterUtilisateur(Utilisateur utilisateur) throws DuplicateItemException {
        if (utilisateursParIdentifiant.containsKey(utilisateur.getIdentifiant())) {
            throw new DuplicateItemException("Identifiant déjà utilisé : " + utilisateur.getIdentifiant());
        }
        utilisateursParIdentifiant.put(utilisateur.getIdentifiant(), utilisateur);
    }

    public Abonne creerCompteAbonne(String identifiant, String motDePasse, String nomAffichage)
            throws ValidationException, DuplicateItemException {
        if (identifiant == null || identifiant.isBlank() || motDePasse == null || motDePasse.isBlank()
                || nomAffichage == null || nomAffichage.isBlank()) {
            throw new ValidationException("Tous les champs de création de compte sont obligatoires.");
        }
        if (motDePasse.trim().length() < 4) {
            throw new ValidationException("Le mot de passe doit contenir au moins 4 caractères.");
        }
        Abonne abonne = new Abonne(identifiant, motDePasse, nomAffichage);
        ajouterUtilisateur(abonne);
        return abonne;
    }

    public Utilisateur authentifier(String identifiant, String motDePasse) throws AuthenticationException {
        Utilisateur utilisateur = utilisateursParIdentifiant.get(identifiant);
        if (utilisateur == null || !utilisateur.verifieMotDePasse(motDePasse)) {
            throw new AuthenticationException("Identifiant ou mot de passe incorrect.");
        }
        if (!utilisateur.estActif()) {
            throw new AuthenticationException("Ce compte est suspendu.");
        }
        return utilisateur;
    }

    public Administrateur authentifierAdmin(String identifiant, String motDePasse) throws AuthenticationException {
        Utilisateur utilisateur = authentifier(identifiant, motDePasse);
        if (!(utilisateur instanceof Administrateur admin)) {
            throw new AuthenticationException("Ce compte n'est pas un compte administrateur.");
        }
        return admin;
    }

    public Abonne authentifierAbonne(String identifiant, String motDePasse) throws AuthenticationException {
        Utilisateur utilisateur = authentifier(identifiant, motDePasse);
        if (!(utilisateur instanceof Abonne abonne)) {
            throw new AuthenticationException("Ce compte n'est pas un compte abonné.");
        }
        return abonne;
    }

    public List<Morceau> rechercherMorceaux(String query) { return catalogue.rechercherMorceaux(query); }
    public List<Album> rechercherAlbums(String query) { return catalogue.rechercherAlbums(query); }
    public List<EntiteArtistique> rechercherEntitesArtistiques(String query) { return catalogue.rechercherEntitesArtistiques(query); }
    public List<Morceau> rechercheAvanceeMorceaux(String query, Genre genre, Integer anneeMin, Integer anneeMax, SongSortMode sortMode) {
        return catalogue.rechercheAvanceeMorceaux(query, genre, anneeMin, anneeMax, sortMode);
    }

    public void ecouterMorceau(SessionContext session, Morceau morceau) throws LimitEcoutesException, PermissionException {
        if (session == null || session.getType() == null) {
            throw new PermissionException("Aucune session active.");
        }
        if (morceau == null) {
            throw new PermissionException("Morceau introuvable.");
        }
        if (session.estVisiteur()) {
            if (!session.consommerEcouteVisiteur()) {
                throw new LimitEcoutesException("Limite de 5 écoutes visiteur atteinte pour cette session.");
            }
        } else if (session.estAbonne()) {
            session.getAbonne().enregistrerEcoute(morceau);
        } else if (!session.estAdmin()) {
            throw new PermissionException("Aucune session active.");
        }
        morceau.incrementerEcoutes();
        ecoutesTotales++;
    }

    public void noterMorceau(Abonne abonne, Morceau morceau, int note, String commentaire) throws ValidationException {
        if (morceau == null) {
            throw new ValidationException("Morceau introuvable.");
        }
        if (note < 1 || note > 5) {
            throw new ValidationException("La note doit être comprise entre 1 et 5.");
        }
        morceau.ajouterOuMettreAJourAvis(abonne.getIdentifiant(), note, commentaire);
    }

    public void supprimerAvis(Abonne abonne, Morceau morceau) throws ValidationException {
        if (morceau == null) {
            throw new ValidationException("Morceau introuvable.");
        }
        morceau.supprimerAvis(abonne.getIdentifiant());
    }

    public List<Morceau> recommanderPour(Abonne abonne, int limit) {
        Genre genreFavori = abonne.determinerGenreFavori();
        String interpreteFavori = abonne.determinerInterpreteFavori();
        return catalogue.getMorceaux().stream()
                .filter(m -> abonne.getHistoriqueEcoutes().stream().noneMatch(h -> h.equals(m)))
                .sorted(Comparator
                        .comparing((Morceau m) -> genreFavori != null && m.getGenre() == genreFavori ? 1 : 0).reversed()
                        .thenComparing(m -> interpreteFavori != null && m.getInterprete().getNom().equals(interpreteFavori) ? 1 : 0,
                                Comparator.reverseOrder())
                        .thenComparing(Morceau::getNoteMoyenne, Comparator.reverseOrder())
                        .thenComparing(Morceau::getNombreEcoutes, Comparator.reverseOrder())
                        .thenComparing(Morceau::getTitre))
                .limit(limit)
                .toList();
    }

    public Playlist creerPlaylist(Abonne abonne, String nom) throws ValidationException {
        if (nom == null || nom.isBlank()) {
            throw new ValidationException("Le nom de la playlist est obligatoire.");
        }
        return abonne.creerPlaylist(nom);
    }

    public void renommerPlaylist(Abonne abonne, String playlistId, String nouveauNom) throws NotFoundException, ValidationException {
        if (nouveauNom == null || nouveauNom.isBlank()) {
            throw new ValidationException("Le nom de la playlist est obligatoire.");
        }
        Playlist playlist = exigerPlaylist(abonne, playlistId);
        playlist.renommer(nouveauNom);
    }

    public void supprimerPlaylist(Abonne abonne, String playlistId) throws NotFoundException {
        Playlist playlist = exigerPlaylist(abonne, playlistId);
        abonne.supprimerPlaylist(playlist);
    }

    public void ajouterMorceauAPlaylist(Abonne abonne, String playlistId, Morceau morceau)
            throws NotFoundException, DuplicateItemException, ValidationException {
        if (morceau == null) {
            throw new ValidationException("Morceau introuvable.");
        }
        Playlist playlist = exigerPlaylist(abonne, playlistId);
        if (!playlist.ajouterMorceau(morceau)) {
            throw new DuplicateItemException("Le morceau est déjà présent dans cette playlist.");
        }
    }

    public int ajouterDepuisAutrePlaylist(Abonne abonne, String cibleId, String sourceId) throws NotFoundException {
        Playlist cible = exigerPlaylist(abonne, cibleId);
        Playlist source = exigerPlaylist(abonne, sourceId);
        return cible.ajouterDepuis(source);
    }

    public void retirerMorceauDePlaylist(Abonne abonne, String playlistId, Morceau morceau)
            throws NotFoundException, ValidationException {
        Playlist playlist = exigerPlaylist(abonne, playlistId);
        if (!playlist.retirerMorceau(morceau)) {
            throw new ValidationException("Le morceau n'est pas présent dans la playlist.");
        }
    }

    private Playlist exigerPlaylist(Abonne abonne, String playlistId) throws NotFoundException {
        Playlist playlist = abonne.getPlaylistParId(playlistId);
        if (playlist == null) {
            throw new NotFoundException("Playlist introuvable.");
        }
        return playlist;
    }

    public Artiste ajouterArtiste(String nom, String pays) throws ValidationException, DuplicateItemException {
        if (nom == null || nom.isBlank()) {
            throw new ValidationException("Nom d'artiste obligatoire.");
        }
        if (catalogue.getArtistes().stream().anyMatch(a -> a.getNom().equalsIgnoreCase(nom.trim()))) {
            throw new DuplicateItemException("Cet artiste existe déjà dans le catalogue.");
        }
        Artiste artiste = new Artiste(nom, pays);
        catalogue.ajouterEntiteArtistique(artiste);
        return artiste;
    }

    public Groupe ajouterGroupe(String nom, String pays) throws ValidationException, DuplicateItemException {
        if (nom == null || nom.isBlank()) {
            throw new ValidationException("Nom de groupe obligatoire.");
        }
        if (catalogue.getGroupes().stream().anyMatch(g -> g.getNom().equalsIgnoreCase(nom.trim()))) {
            throw new DuplicateItemException("Ce groupe existe déjà dans le catalogue.");
        }
        Groupe groupe = new Groupe(nom, pays);
        catalogue.ajouterEntiteArtistique(groupe);
        return groupe;
    }

    public void lierArtisteAuGroupe(Groupe groupe, Artiste artiste) throws ValidationException {
        if (groupe == null || artiste == null) {
            throw new ValidationException("Artiste ou groupe introuvable.");
        }
        groupe.ajouterMembre(artiste);
    }

    public Album ajouterAlbum(String titre, int annee, EntiteArtistique artiste) throws ValidationException, DuplicateItemException {
        if (titre == null || titre.isBlank()) {
            throw new ValidationException("Titre d'album obligatoire.");
        }
        if (annee < 1900 || annee > 2026) {
            throw new ValidationException("Année d'album invalide.");
        }
        if (artiste == null) {
            throw new ValidationException("Interprète obligatoire.");
        }
        boolean existe = catalogue.getAlbums().stream().anyMatch(a -> a.getTitre().equalsIgnoreCase(titre.trim()) && a.getArtiste().equals(artiste));
        if (existe) {
            throw new DuplicateItemException("Cet album existe déjà pour cet interprète.");
        }
        Album album = new Album(titre, annee, artiste);
        catalogue.ajouterAlbum(album);
        return album;
    }

    public Morceau ajouterMorceau(String titre, int dureeSecondes, Genre genre, int annee, EntiteArtistique artiste, List<Album> albumsAssocies)
            throws ValidationException, DuplicateItemException {
        if (titre == null || titre.isBlank()) {
            throw new ValidationException("Titre de morceau obligatoire.");
        }
        if (dureeSecondes <= 0) {
            throw new ValidationException("Durée invalide.");
        }
        if (annee < 1900 || annee > 2026) {
            throw new ValidationException("Année du morceau invalide.");
        }
        if (artiste == null) {
            throw new ValidationException("Interprète obligatoire.");
        }
        boolean existe = catalogue.getMorceaux().stream().anyMatch(m -> m.getTitre().equalsIgnoreCase(titre.trim()) && m.getInterprete().equals(artiste));
        if (existe) {
            throw new DuplicateItemException("Ce morceau existe déjà pour cet interprète.");
        }
        Morceau morceau = new Morceau(titre, dureeSecondes, genre, annee, artiste);
        catalogue.ajouterMorceau(morceau);
        if (albumsAssocies != null) {
            for (Album album : albumsAssocies) {
                album.ajouterMorceau(morceau);
            }
        }
        return morceau;
    }

    public void supprimerMorceau(String morceauId) throws NotFoundException {
        Morceau morceau = catalogue.removeMorceau(morceauId);
        if (morceau == null) {
            throw new NotFoundException("Morceau introuvable.");
        }
        for (Album album : new ArrayList<>(morceau.getAlbums())) {
            album.retirerMorceau(morceau);
        }
        for (Utilisateur utilisateur : utilisateursParIdentifiant.values()) {
            if (utilisateur instanceof Abonne abonne) {
                abonne.nettoyerReferencesMorceau(morceau);
            }
        }
    }

    public void supprimerAlbum(String albumId) throws NotFoundException {
        Album album = catalogue.removeAlbum(albumId);
        if (album == null) {
            throw new NotFoundException("Album introuvable.");
        }
        for (Morceau morceau : new ArrayList<>(album.getMorceaux())) {
            album.retirerMorceau(morceau);
        }
    }

    public void supprimerEntiteArtistique(String entiteId) throws NotFoundException {
        EntiteArtistique entite = catalogue.removeEntiteArtistique(entiteId);
        if (entite == null) {
            throw new NotFoundException("Artiste / groupe introuvable.");
        }
        List<Album> albumsASupprimer = catalogue.getAlbums().stream().filter(a -> a.getArtiste().equals(entite)).toList();
        for (Album album : albumsASupprimer) {
            supprimerAlbum(album.getId());
        }
        List<Morceau> morceauxASupprimer = catalogue.getMorceaux().stream().filter(m -> m.getInterprete().equals(entite)).toList();
        for (Morceau morceau : morceauxASupprimer) {
            supprimerMorceau(morceau.getId());
        }
    }

    public void suspendreCompteAbonne(String identifiant) throws NotFoundException, ValidationException {
        Utilisateur utilisateur = utilisateursParIdentifiant.get(identifiant);
        if (utilisateur == null) {
            throw new NotFoundException("Utilisateur introuvable.");
        }
        if (!(utilisateur instanceof Abonne)) {
            throw new ValidationException("Seuls les abonnés peuvent être suspendus.");
        }
        utilisateur.suspendre();
    }

    public void reactiverCompteAbonne(String identifiant) throws NotFoundException, ValidationException {
        Utilisateur utilisateur = utilisateursParIdentifiant.get(identifiant);
        if (utilisateur == null) {
            throw new NotFoundException("Utilisateur introuvable.");
        }
        if (!(utilisateur instanceof Abonne)) {
            throw new ValidationException("Seuls les abonnés peuvent être réactivés.");
        }
        utilisateur.reactiver();
    }

    public void supprimerCompteAbonne(String identifiant) throws NotFoundException, ValidationException {
        Utilisateur utilisateur = utilisateursParIdentifiant.get(identifiant);
        if (utilisateur == null) {
            throw new NotFoundException("Utilisateur introuvable.");
        }
        if (!(utilisateur instanceof Abonne)) {
            throw new ValidationException("Seuls les abonnés peuvent être supprimés.");
        }
        utilisateursParIdentifiant.remove(identifiant);
    }

    public StatistiquesSnapshot getStatistiques() {
        int nbAdmins = (int) utilisateursParIdentifiant.values().stream().filter(Administrateur.class::isInstance).count();
        int nbAbonnes = (int) utilisateursParIdentifiant.values().stream().filter(Abonne.class::isInstance).count();
        long totalEcoutes = getEcoutesTotales();
        return new StatistiquesSnapshot(
                utilisateursParIdentifiant.size(),
                nbAbonnes,
                nbAdmins,
                catalogue.getMorceaux().size(),
                catalogue.getAlbums().size(),
                catalogue.getEntitesArtistiques().size(),
                totalEcoutes,
                catalogue.getTopEcoutes(5),
                catalogue.getTopNotes(5),
                catalogue.getTopAjoutsPlaylists(5),
                catalogue.getEcoutesParGenre()
        );
    }

    public String getDetailsNavigation(Morceau morceau) {
        return catalogue.detailsNavigationDepuisMorceau(morceau);
    }
}
