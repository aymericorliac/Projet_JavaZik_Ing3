package javazik.model.core;

import javazik.exception.DuplicateItemException;
import javazik.exception.ValidationException;
import javazik.model.media.Album;
import javazik.model.media.Artiste;
import javazik.model.media.Genre;
import javazik.model.media.Groupe;
import javazik.model.media.Morceau;
import javazik.model.user.Administrateur;

import java.util.List;

/**
 * Jeu de données de démonstration constitué uniquement d'artistes, groupes,
 * albums et morceaux connus, afin de rendre les démos plus parlantes.
 */
public final class DemoDataFactory {
    private DemoDataFactory() {
    }

    public static void initializeIfEmpty(PlateformeMusicale plateforme) {
        if (!plateforme.getCatalogue().getMorceaux().isEmpty() || !plateforme.getUtilisateurs().isEmpty()) {
            return;
        }
        try {
            remplir(plateforme);
        } catch (ValidationException | DuplicateItemException e) {
            throw new IllegalStateException("Erreur lors de l'initialisation", e);
        }
    }

    private static void remplir(PlateformeMusicale plateforme) throws ValidationException, DuplicateItemException {
        Administrateur admin = new Administrateur("admin", "admin123", "Admin Javazik");
        plateforme.ajouterUtilisateur(admin);
        var alice = plateforme.creerCompteAbonne("alice", "alice123", "Alice");
        var bob = plateforme.creerCompteAbonne("bob", "bob123", "Bob");
        var charlie = plateforme.creerCompteAbonne("charlie", "charlie123", "Charlie");

        Artiste adele = plateforme.ajouterArtiste("Adele", "Royaume-Uni");
        Artiste freddie = plateforme.ajouterArtiste("Freddie Mercury", "Royaume-Uni");
        Artiste chrisMartin = plateforme.ajouterArtiste("Chris Martin", "Royaume-Uni");
        Artiste michaelJackson = plateforme.ajouterArtiste("Michael Jackson", "États-Unis");
        Artiste beyonce = plateforme.ajouterArtiste("Beyoncé", "États-Unis");
        Artiste edSheeran = plateforme.ajouterArtiste("Ed Sheeran", "Royaume-Uni");
        Artiste brunoMars = plateforme.ajouterArtiste("Bruno Mars", "États-Unis");
        Artiste ladyGaga = plateforme.ajouterArtiste("Lady Gaga", "États-Unis");
        Artiste thomas = plateforme.ajouterArtiste("Thomas Bangalter", "France");
        Artiste guy = plateforme.ajouterArtiste("Guy-Manuel de Homem-Christo", "France");
        Artiste danReynolds = plateforme.ajouterArtiste("Dan Reynolds", "États-Unis");

        Groupe queen = plateforme.ajouterGroupe("Queen", "Royaume-Uni");
        plateforme.lierArtisteAuGroupe(queen, freddie);
        Groupe coldplay = plateforme.ajouterGroupe("Coldplay", "Royaume-Uni");
        plateforme.lierArtisteAuGroupe(coldplay, chrisMartin);
        Groupe daftPunk = plateforme.ajouterGroupe("Daft Punk", "France");
        plateforme.lierArtisteAuGroupe(daftPunk, thomas);
        plateforme.lierArtisteAuGroupe(daftPunk, guy);
        Groupe beatles = plateforme.ajouterGroupe("The Beatles", "Royaume-Uni");
        Groupe abba = plateforme.ajouterGroupe("ABBA", "Suède");
        Groupe imagineDragons = plateforme.ajouterGroupe("Imagine Dragons", "États-Unis");
        plateforme.lierArtisteAuGroupe(imagineDragons, danReynolds);

        Album nightAtOpera = plateforme.ajouterAlbum("A Night at the Opera", 1975, queen);
        Album jazz = plateforme.ajouterAlbum("Jazz", 1978, queen);
        Album discovery = plateforme.ajouterAlbum("Discovery", 2001, daftPunk);
        Album randomAccess = plateforme.ajouterAlbum("Random Access Memories", 2013, daftPunk);
        Album album25 = plateforme.ajouterAlbum("25", 2015, adele);
        Album album21 = plateforme.ajouterAlbum("21", 2011, adele);
        Album parachutes = plateforme.ajouterAlbum("Parachutes", 2000, coldplay);
        Album vivaLaVida = plateforme.ajouterAlbum("Viva la Vida or Death and All His Friends", 2008, coldplay);
        Album thriller = plateforme.ajouterAlbum("Thriller", 1982, michaelJackson);
        Album dangerous = plateforme.ajouterAlbum("Dangerous", 1991, michaelJackson);
        Album lemonade = plateforme.ajouterAlbum("Lemonade", 2016, beyonce);
        Album iAmSashaFierce = plateforme.ajouterAlbum("I Am... Sasha Fierce", 2008, beyonce);
        Album divide = plateforme.ajouterAlbum("÷", 2017, edSheeran);
        Album x = plateforme.ajouterAlbum("x", 2014, edSheeran);
        Album dooWops = plateforme.ajouterAlbum("Doo-Wops & Hooligans", 2010, brunoMars);
        Album unorthodox = plateforme.ajouterAlbum("Unorthodox Jukebox", 2012, brunoMars);
        Album fameMonster = plateforme.ajouterAlbum("The Fame Monster", 2009, ladyGaga);
        Album theBeatles1 = plateforme.ajouterAlbum("1", 2000, beatles);
        Album abbeyRoad = plateforme.ajouterAlbum("Abbey Road", 1969, beatles);
        Album gold = plateforme.ajouterAlbum("Gold", 1992, abba);
        Album evolve = plateforme.ajouterAlbum("Evolve", 2017, imagineDragons);
        Album nightVisions = plateforme.ajouterAlbum("Night Visions", 2012, imagineDragons);

        // Queen
        Morceau bohemian = plateforme.ajouterMorceau("Bohemian Rhapsody", 354, Genre.ROCK, 1975, queen, List.of(nightAtOpera));
        Morceau loveOfMyLife = plateforme.ajouterMorceau("Love of My Life", 219, Genre.ROCK, 1975, queen, List.of(nightAtOpera));
        Morceau dontStopMeNow = plateforme.ajouterMorceau("Don't Stop Me Now", 209, Genre.ROCK, 1978, queen, List.of(jazz));

        // Daft Punk
        Morceau oneMoreTime = plateforme.ajouterMorceau("One More Time", 320, Genre.ELECTRO, 2000, daftPunk, List.of(discovery));
        Morceau harderBetter = plateforme.ajouterMorceau("Harder, Better, Faster, Stronger", 225, Genre.ELECTRO, 2001, daftPunk, List.of(discovery));
        Morceau getLucky = plateforme.ajouterMorceau("Get Lucky", 369, Genre.FUNK, 2013, daftPunk, List.of(randomAccess));
        Morceau instantCrush = plateforme.ajouterMorceau("Instant Crush", 337, Genre.POP, 2013, daftPunk, List.of(randomAccess));

        // Adele
        Morceau hello = plateforme.ajouterMorceau("Hello", 295, Genre.POP, 2015, adele, List.of(album25));
        Morceau sendMyLove = plateforme.ajouterMorceau("Send My Love", 223, Genre.POP, 2015, adele, List.of(album25));
        Morceau rolling = plateforme.ajouterMorceau("Rolling in the Deep", 228, Genre.POP, 2011, adele, List.of(album21));
        Morceau someoneLikeYou = plateforme.ajouterMorceau("Someone Like You", 285, Genre.POP, 2011, adele, List.of(album21));

        // Coldplay
        Morceau yellow = plateforme.ajouterMorceau("Yellow", 269, Genre.ROCK, 2000, coldplay, List.of(parachutes));
        Morceau trouble = plateforme.ajouterMorceau("Trouble", 271, Genre.ROCK, 2000, coldplay, List.of(parachutes));
        Morceau clocks = plateforme.ajouterMorceau("Clocks", 307, Genre.ROCK, 2002, coldplay, List.of());
        Morceau viva = plateforme.ajouterMorceau("Viva la Vida", 242, Genre.ROCK, 2008, coldplay, List.of(vivaLaVida));

        // Michael Jackson
        Morceau billieJean = plateforme.ajouterMorceau("Billie Jean", 294, Genre.POP, 1982, michaelJackson, List.of(thriller));
        Morceau beatIt = plateforme.ajouterMorceau("Beat It", 258, Genre.ROCK, 1982, michaelJackson, List.of(thriller));
        Morceau thrillerTrack = plateforme.ajouterMorceau("Thriller", 357, Genre.POP, 1982, michaelJackson, List.of(thriller));
        Morceau blackOrWhite = plateforme.ajouterMorceau("Black or White", 262, Genre.POP, 1991, michaelJackson, List.of(dangerous));

        // Beyoncé
        Morceau halo = plateforme.ajouterMorceau("Halo", 261, Genre.RNB, 2008, beyonce, List.of(iAmSashaFierce));
        Morceau singleLadies = plateforme.ajouterMorceau("Single Ladies", 193, Genre.RNB, 2008, beyonce, List.of(iAmSashaFierce));
        Morceau formation = plateforme.ajouterMorceau("Formation", 206, Genre.RNB, 2016, beyonce, List.of(lemonade));
        Morceau crazyInLove = plateforme.ajouterMorceau("Crazy in Love", 236, Genre.RNB, 2003, beyonce, List.of());

        // Ed Sheeran
        Morceau shapeOfYou = plateforme.ajouterMorceau("Shape of You", 233, Genre.POP, 2017, edSheeran, List.of(divide));
        Morceau perfect = plateforme.ajouterMorceau("Perfect", 263, Genre.POP, 2017, edSheeran, List.of(divide));
        Morceau thinkingOutLoud = plateforme.ajouterMorceau("Thinking Out Loud", 281, Genre.POP, 2014, edSheeran, List.of(x));

        // Bruno Mars
        Morceau justTheWay = plateforme.ajouterMorceau("Just the Way You Are", 221, Genre.POP, 2010, brunoMars, List.of(dooWops));
        Morceau lockedOut = plateforme.ajouterMorceau("Locked Out of Heaven", 233, Genre.POP, 2012, brunoMars, List.of(unorthodox));
        Morceau grenade = plateforme.ajouterMorceau("Grenade", 223, Genre.POP, 2010, brunoMars, List.of(dooWops));

        // Lady Gaga
        Morceau badRomance = plateforme.ajouterMorceau("Bad Romance", 294, Genre.POP, 2009, ladyGaga, List.of(fameMonster));
        Morceau pokerFace = plateforme.ajouterMorceau("Poker Face", 238, Genre.POP, 2008, ladyGaga, List.of());

        // Beatles
        Morceau comeTogether = plateforme.ajouterMorceau("Come Together", 260, Genre.ROCK, 1969, beatles, List.of(abbeyRoad, theBeatles1));
        Morceau hereComesSun = plateforme.ajouterMorceau("Here Comes the Sun", 185, Genre.ROCK, 1969, beatles, List.of(abbeyRoad));
        Morceau letItBe = plateforme.ajouterMorceau("Let It Be", 243, Genre.ROCK, 1970, beatles, List.of(theBeatles1));
        Morceau heyJude = plateforme.ajouterMorceau("Hey Jude", 431, Genre.ROCK, 1968, beatles, List.of(theBeatles1));

        // ABBA
        Morceau dancingQueen = plateforme.ajouterMorceau("Dancing Queen", 231, Genre.POP, 1976, abba, List.of(gold));
        Morceau mammaMia = plateforme.ajouterMorceau("Mamma Mia", 215, Genre.POP, 1975, abba, List.of(gold));

        // Imagine Dragons
        Morceau believer = plateforme.ajouterMorceau("Believer", 204, Genre.ROCK, 2017, imagineDragons, List.of(evolve));
        Morceau thunder = plateforme.ajouterMorceau("Thunder", 187, Genre.ROCK, 2017, imagineDragons, List.of(evolve));
        Morceau radioactive = plateforme.ajouterMorceau("Radioactive", 186, Genre.ROCK, 2012, imagineDragons, List.of(nightVisions));
        Morceau demons = plateforme.ajouterMorceau("Demons", 177, Genre.ROCK, 2012, imagineDragons, List.of(nightVisions));

        seedEcoutes(bohemian, 18);
        seedEcoutes(oneMoreTime, 15);
        seedEcoutes(billieJean, 14);
        seedEcoutes(hello, 12);
        seedEcoutes(yellow, 11);
        seedEcoutes(getLucky, 10);
        seedEcoutes(shapeOfYou, 10);
        seedEcoutes(viva, 9);
        seedEcoutes(halo, 9);
        seedEcoutes(badRomance, 8);
        seedEcoutes(dancingQueen, 8);
        seedEcoutes(believer, 8);
        seedEcoutes(comeTogether, 7);

        try {
            plateforme.noterMorceau(plateforme.authentifierAbonne("alice", "alice123"), bohemian, 5, "Un classique absolu.");
            plateforme.noterMorceau(plateforme.authentifierAbonne("alice", "alice123"), oneMoreTime, 5, "Parfait pour lancer une démonstration.");
            plateforme.noterMorceau(plateforme.authentifierAbonne("alice", "alice123"), billieJean, 5, "Rythme légendaire.");
            plateforme.noterMorceau(plateforme.authentifierAbonne("bob", "bob123"), hello, 5, "Interprétation incroyable.");
            plateforme.noterMorceau(plateforme.authentifierAbonne("bob", "bob123"), yellow, 4, "Toujours aussi beau.");
            plateforme.noterMorceau(plateforme.authentifierAbonne("bob", "bob123"), halo, 5, "Très puissante.");
            plateforme.noterMorceau(plateforme.authentifierAbonne("charlie", "charlie123"), shapeOfYou, 4, "Très efficace.");
            plateforme.noterMorceau(plateforme.authentifierAbonne("charlie", "charlie123"), dancingQueen, 5, "Inratable en soirée.");

            var p1 = plateforme.creerPlaylist(alice, "Soirée Pop-Rock");
            plateforme.ajouterMorceauAPlaylist(alice, p1.getId(), bohemian);
            plateforme.ajouterMorceauAPlaylist(alice, p1.getId(), billieJean);
            plateforme.ajouterMorceauAPlaylist(alice, p1.getId(), dontStopMeNow);
            plateforme.ajouterMorceauAPlaylist(alice, p1.getId(), shapeOfYou);

            var p2 = plateforme.creerPlaylist(bob, "Chill & émotion");
            plateforme.ajouterMorceauAPlaylist(bob, p2.getId(), hello);
            plateforme.ajouterMorceauAPlaylist(bob, p2.getId(), someoneLikeYou);
            plateforme.ajouterMorceauAPlaylist(bob, p2.getId(), yellow);
            plateforme.ajouterMorceauAPlaylist(bob, p2.getId(), halo);

            var p3 = plateforme.creerPlaylist(charlie, "Énergie & classique connu");
            plateforme.ajouterMorceauAPlaylist(charlie, p3.getId(), oneMoreTime);
            plateforme.ajouterMorceauAPlaylist(charlie, p3.getId(), getLucky);
            plateforme.ajouterMorceauAPlaylist(charlie, p3.getId(), believer);
            plateforme.ajouterMorceauAPlaylist(charlie, p3.getId(), dancingQueen);
        } catch (Exception e) {
            throw new IllegalStateException(e);
        }
    }

    private static void seedEcoutes(Morceau morceau, int count) {
        for (int i = 0; i < count; i++) {
            morceau.incrementerEcoutes();
        }
    }
}
