package javazik.model.core;

import javazik.model.media.Album;
import javazik.model.media.Artiste;
import javazik.model.media.EntiteArtistique;
import javazik.model.media.Genre;
import javazik.model.media.Groupe;
import javazik.model.media.Morceau;
import javazik.model.media.SongSortMode;

import java.io.Serial;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.EnumMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Catalogue central de l'application.
 */
public class Catalogue implements Serializable {
    @Serial
    private static final long serialVersionUID = 1L;

    private final Map<String, EntiteArtistique> entitesArtistiques;
    private final Map<String, Album> albums;
    private final Map<String, Morceau> morceaux;

    public Catalogue() {
        this.entitesArtistiques = new LinkedHashMap<>();
        this.albums = new LinkedHashMap<>();
        this.morceaux = new LinkedHashMap<>();
    }

    public List<EntiteArtistique> getEntitesArtistiques() { return new ArrayList<>(entitesArtistiques.values()); }
    public List<Artiste> getArtistes() {
        return entitesArtistiques.values().stream().filter(Artiste.class::isInstance).map(Artiste.class::cast).toList();
    }
    public List<Groupe> getGroupes() {
        return entitesArtistiques.values().stream().filter(Groupe.class::isInstance).map(Groupe.class::cast).toList();
    }
    public List<Album> getAlbums() { return new ArrayList<>(albums.values()); }
    public List<Morceau> getMorceaux() { return new ArrayList<>(morceaux.values()); }

    public void ajouterEntiteArtistique(EntiteArtistique entiteArtistique) { entitesArtistiques.put(entiteArtistique.getId(), entiteArtistique); }
    public void ajouterAlbum(Album album) { albums.put(album.getId(), album); }
    public void ajouterMorceau(Morceau morceau) { morceaux.put(morceau.getId(), morceau); }
    public EntiteArtistique getEntiteArtistiqueById(String id) { return entitesArtistiques.get(id); }
    public Album getAlbumById(String id) { return albums.get(id); }
    public Morceau getMorceauById(String id) { return morceaux.get(id); }
    public EntiteArtistique removeEntiteArtistique(String id) { return entitesArtistiques.remove(id); }
    public Album removeAlbum(String id) { return albums.remove(id); }
    public Morceau removeMorceau(String id) { return morceaux.remove(id); }

    public List<Morceau> rechercherMorceaux(String query) {
        String q = normaliser(query);
        return morceaux.values().stream()
                .filter(m -> q.isBlank() || normaliser(m.getTitre()).contains(q) || normaliser(m.getInterprete().getNom()).contains(q))
                .sorted(Comparator.comparing(Morceau::getTitre))
                .toList();
    }

    public List<Album> rechercherAlbums(String query) {
        String q = normaliser(query);
        return albums.values().stream()
                .filter(a -> q.isBlank() || normaliser(a.getTitre()).contains(q) || normaliser(a.getArtiste().getNom()).contains(q))
                .sorted(Comparator.comparing(Album::getTitre))
                .toList();
    }

    public List<EntiteArtistique> rechercherEntitesArtistiques(String query) {
        String q = normaliser(query);
        return entitesArtistiques.values().stream()
                .filter(a -> q.isBlank() || normaliser(a.getNom()).contains(q))
                .sorted(Comparator.comparing(EntiteArtistique::getNom))
                .toList();
    }

    public List<Morceau> rechercheAvanceeMorceaux(String query, Genre genre, Integer anneeMin, Integer anneeMax, SongSortMode sortMode) {
        String q = normaliser(query);
        Comparator<Morceau> comparator = switch (sortMode == null ? SongSortMode.TITRE : sortMode) {
            case TITRE -> Comparator.comparing(Morceau::getTitre);
            case ANNEE -> Comparator.comparingInt(Morceau::getAnnee).thenComparing(Morceau::getTitre);
            case DUREE -> Comparator.comparingInt(Morceau::getDureeSecondes).thenComparing(Morceau::getTitre);
            case ECOUTES -> Comparator.comparingInt(Morceau::getNombreEcoutes).reversed().thenComparing(Morceau::getTitre);
            case NOTE_MOYENNE -> Comparator.comparingDouble(Morceau::getNoteMoyenne).reversed().thenComparing(Morceau::getTitre);
        };

        return morceaux.values().stream()
                .filter(m -> q.isBlank() || normaliser(m.getTitre()).contains(q) || normaliser(m.getInterprete().getNom()).contains(q))
                .filter(m -> genre == null || m.getGenre() == genre)
                .filter(m -> anneeMin == null || m.getAnnee() >= anneeMin)
                .filter(m -> anneeMax == null || m.getAnnee() <= anneeMax)
                .sorted(comparator)
                .toList();
    }

    public List<Morceau> getMorceauxParEntite(EntiteArtistique entite) {
        return morceaux.values().stream()
                .filter(m -> m.getInterprete().equals(entite))
                .sorted(Comparator.comparing(Morceau::getTitre))
                .toList();
    }

    public List<Album> getAlbumsParEntite(EntiteArtistique entite) {
        return albums.values().stream()
                .filter(a -> a.getArtiste().equals(entite))
                .sorted(Comparator.comparing(Album::getAnnee).thenComparing(Album::getTitre))
                .toList();
    }

    public List<Morceau> getMorceauxParAlbum(Album album) {
        return album.getMorceaux().stream().sorted(Comparator.comparing(Morceau::getTitre)).toList();
    }

    public List<Morceau> getTopEcoutes(int limit) {
        return morceaux.values().stream()
                .sorted(Comparator.comparingInt(Morceau::getNombreEcoutes).reversed().thenComparing(Morceau::getTitre))
                .limit(limit)
                .toList();
    }

    public List<Morceau> getTopNotes(int limit) {
        return morceaux.values().stream()
                .filter(m -> !m.getAvis().isEmpty())
                .sorted(Comparator.comparingDouble(Morceau::getNoteMoyenne).reversed().thenComparing(Morceau::getTitre))
                .limit(limit)
                .toList();
    }

    public List<Morceau> getTopAjoutsPlaylists(int limit) {
        return morceaux.values().stream()
                .filter(m -> m.getNombreAjoutsPlaylists() > 0)
                .sorted(Comparator.comparingInt(Morceau::getNombreAjoutsPlaylists).reversed().thenComparing(Morceau::getTitre))
                .limit(limit)
                .toList();
    }

    public Map<Genre, Long> getEcoutesParGenre() {
        Map<Genre, Long> stats = new EnumMap<>(Genre.class);
        for (Morceau morceau : morceaux.values()) {
            stats.merge(morceau.getGenre(), (long) morceau.getNombreEcoutes(), Long::sum);
        }
        return stats;
    }

    public String detailsNavigationDepuisMorceau(Morceau morceau) {
        StringBuilder sb = new StringBuilder(morceau.descriptionDetaillee());
        EntiteArtistique interprete = morceau.getInterprete();
        sb.append(System.lineSeparator()).append(System.lineSeparator())
                .append("Explorer ").append(interprete.getNom()).append(" :");
        List<Morceau> autres = getMorceauxParEntite(interprete).stream()
                .filter(m -> !m.equals(morceau))
                .limit(5)
                .toList();
        if (autres.isEmpty()) {
            sb.append(System.lineSeparator()).append(" - Aucun autre morceau");
        } else {
            for (Morceau autre : autres) {
                sb.append(System.lineSeparator()).append(" - ").append(autre.getTitre());
            }
        }
        sb.append(System.lineSeparator()).append(System.lineSeparator()).append("Albums associés :");
        if (morceau.getAlbums().isEmpty()) {
            sb.append(System.lineSeparator()).append(" - Aucun album");
        } else {
            for (Album album : morceau.getAlbums()) {
                sb.append(System.lineSeparator()).append(" - ").append(album.getTitre()).append(" (").append(album.getAnnee()).append(")");
            }
        }
        return sb.toString();
    }

    private String normaliser(String texte) {
        return texte == null ? "" : texte.toLowerCase(Locale.ROOT).trim();
    }
}
