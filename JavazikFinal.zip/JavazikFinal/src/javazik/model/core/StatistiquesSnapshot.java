package javazik.model.core;

import javazik.model.media.Genre;
import javazik.model.media.Morceau;

import java.io.Serial;
import java.io.Serializable;
import java.util.Collections;
import java.util.List;
import java.util.Map;

/**
 * Instantané immuable des statistiques exposées à l'administrateur.
 */
public class StatistiquesSnapshot implements Serializable {
    @Serial
    private static final long serialVersionUID = 1L;

    private final int nombreUtilisateurs;
    private final int nombreAbonnes;
    private final int nombreAdmins;
    private final int nombreMorceaux;
    private final int nombreAlbums;
    private final int nombreArtistesOuGroupes;
    private final long nombreEcoutesTotales;
    private final List<Morceau> topEcoutes;
    private final List<Morceau> topNotes;
    private final List<Morceau> topAjoutsPlaylists;
    private final Map<Genre, Long> ecoutesParGenre;

    public StatistiquesSnapshot(
            int nombreUtilisateurs,
            int nombreAbonnes,
            int nombreAdmins,
            int nombreMorceaux,
            int nombreAlbums,
            int nombreArtistesOuGroupes,
            long nombreEcoutesTotales,
            List<Morceau> topEcoutes,
            List<Morceau> topNotes,
            List<Morceau> topAjoutsPlaylists,
            Map<Genre, Long> ecoutesParGenre) {
        this.nombreUtilisateurs = nombreUtilisateurs;
        this.nombreAbonnes = nombreAbonnes;
        this.nombreAdmins = nombreAdmins;
        this.nombreMorceaux = nombreMorceaux;
        this.nombreAlbums = nombreAlbums;
        this.nombreArtistesOuGroupes = nombreArtistesOuGroupes;
        this.nombreEcoutesTotales = nombreEcoutesTotales;
        this.topEcoutes = List.copyOf(topEcoutes);
        this.topNotes = List.copyOf(topNotes);
        this.topAjoutsPlaylists = List.copyOf(topAjoutsPlaylists);
        this.ecoutesParGenre = Map.copyOf(ecoutesParGenre);
    }

    public int getNombreUtilisateurs() { return nombreUtilisateurs; }
    public int getNombreAbonnes() { return nombreAbonnes; }
    public int getNombreAdmins() { return nombreAdmins; }
    public int getNombreMorceaux() { return nombreMorceaux; }
    public int getNombreAlbums() { return nombreAlbums; }
    public int getNombreArtistesOuGroupes() { return nombreArtistesOuGroupes; }
    public long getNombreEcoutesTotales() { return nombreEcoutesTotales; }
    public List<Morceau> getTopEcoutes() { return Collections.unmodifiableList(topEcoutes); }
    public List<Morceau> getTopNotes() { return Collections.unmodifiableList(topNotes); }
    public List<Morceau> getTopAjoutsPlaylists() { return Collections.unmodifiableList(topAjoutsPlaylists); }
    public Map<Genre, Long> getEcoutesParGenre() { return Collections.unmodifiableMap(ecoutesParGenre); }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Utilisateurs : ").append(nombreUtilisateurs).append(System.lineSeparator());
        sb.append("Abonnés : ").append(nombreAbonnes).append(System.lineSeparator());
        sb.append("Administrateurs : ").append(nombreAdmins).append(System.lineSeparator());
        sb.append("Morceaux : ").append(nombreMorceaux).append(System.lineSeparator());
        sb.append("Albums : ").append(nombreAlbums).append(System.lineSeparator());
        sb.append("Artistes / groupes : ").append(nombreArtistesOuGroupes).append(System.lineSeparator());
        sb.append("Écoutes totales : ").append(nombreEcoutesTotales).append(System.lineSeparator());
        appendListe(sb, "Top écoutes", topEcoutes, m -> m.getTitre() + " (" + m.getNombreEcoutes() + " écoute(s))");
        appendListe(sb, "Top notes", topNotes, m -> m.getTitre() + " (" + String.format(java.util.Locale.US, "%.2f", m.getNoteMoyenne()) + "/5)");
        appendListe(sb, "Top ajouts playlists", topAjoutsPlaylists, m -> m.getTitre() + " (" + m.getNombreAjoutsPlaylists() + " ajout(s))");
        if (!ecoutesParGenre.isEmpty()) {
            sb.append("Répartition des écoutes par genre :").append(System.lineSeparator());
            ecoutesParGenre.forEach((genre, value) -> sb.append(" - ").append(genre).append(" : ").append(value).append(System.lineSeparator()));
        }
        return sb.toString().trim();
    }

    private static void appendListe(StringBuilder sb, String titre, List<Morceau> liste, java.util.function.Function<Morceau, String> formatter) {
        if (!liste.isEmpty()) {
            sb.append(titre).append(" :").append(System.lineSeparator());
            for (Morceau morceau : liste) {
                sb.append(" - ").append(formatter.apply(morceau)).append(System.lineSeparator());
            }
        }
    }
}
