package javazik.model;

/**
 * Contrat simple pour les objets pouvant fournir une description textuelle.
 */
public interface Descriptible {
    String descriptionCourte();
    String descriptionDetaillee();
}
