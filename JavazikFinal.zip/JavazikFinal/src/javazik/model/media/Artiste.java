package javazik.model.media;

import java.io.Serial;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Artiste extends EntiteArtistique {
    @Serial
    private static final long serialVersionUID = 1L;

    private final List<Groupe> groupes;

    public Artiste(String nom, String pays) {
        super(nom, pays);
        this.groupes = new ArrayList<>();
    }

    @Override
    public String getTypeLabel() {
        return "Artiste";
    }

    public void ajouterGroupe(Groupe groupe) {
        if (groupe != null && !groupes.contains(groupe)) {
            groupes.add(groupe);
        }
    }

    public List<Groupe> getGroupes() {
        return Collections.unmodifiableList(groupes);
    }

    @Override
    public String descriptionDetaillee() {
        StringBuilder sb = new StringBuilder(super.descriptionDetaillee());
        if (!groupes.isEmpty()) {
            sb.append(System.lineSeparator()).append("Membre de : ");
            for (int i = 0; i < groupes.size(); i++) {
                if (i > 0) sb.append(", ");
                sb.append(groupes.get(i).getNom());
            }
        }
        return sb.toString();
    }
}
