package javazik.model.media;

/**
 * Genres gérés par l'application.
 */
public enum Genre {
    POP("Pop"),
    ROCK("Rock"),
    ELECTRO("Électro"),
    SOUL("Soul"),
    HIP_HOP("Hip-hop"),
    CLASSIQUE("Classique"),
    JAZZ("Jazz"),
    RNB("R&B"),
    FUNK("Funk"),
    AUTRE("Autre");

    private final String label;

    Genre(String label) {
        this.label = label;
    }

    @Override
    public String toString() {
        return label;
    }
}
