package javazik.model.media;

import javazik.model.Descriptible;

import java.io.Serial;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.UUID;

public class Album implements Serializable, Descriptible {
    @Serial
    private static final long serialVersionUID = 1L;

    private final String id;
    private final String titre;
    private final int annee;
    private final EntiteArtistique artiste;
    private final List<Morceau> morceaux;

    public Album(String titre, int annee, EntiteArtistique artiste) {
        this.id = UUID.randomUUID().toString();
        this.titre = Objects.requireNonNull(titre, "Le titre est obligatoire").trim();
        this.annee = annee;
        this.artiste = Objects.requireNonNull(artiste, "L'artiste est obligatoire");
        this.morceaux = new ArrayList<>();
    }

    public String getId() { return id; }
    public String getTitre() { return titre; }
    public int getAnnee() { return annee; }
    public EntiteArtistique getArtiste() { return artiste; }
    public List<Morceau> getMorceaux() { return Collections.unmodifiableList(morceaux); }

    public void ajouterMorceau(Morceau morceau) {
        if (morceau != null && !morceaux.contains(morceau)) {
            morceaux.add(morceau);
            morceau.ajouterAlbum(this);
        }
    }

    public void retirerMorceau(Morceau morceau) {
        if (morceau != null && morceaux.remove(morceau)) {
            morceau.retirerAlbum(this);
        }
    }

    @Override
    public String descriptionCourte() {
        return "Album - " + titre + " (" + annee + ") - " + artiste.getNom();
    }

    @Override
    public String descriptionDetaillee() {
        StringBuilder sb = new StringBuilder(descriptionCourte());
        sb.append(System.lineSeparator()).append("Nombre de morceaux : ").append(morceaux.size());
        for (Morceau morceau : morceaux) {
            sb.append(System.lineSeparator()).append(" - ").append(morceau.getTitre());
        }
        return sb.toString();
    }

    @Override
    public String toString() { return descriptionCourte(); }

    @Override
    public boolean equals(Object o) {
        if (!(o instanceof Album album)) return false;
        return id.equals(album.id);
    }

    @Override
    public int hashCode() { return id.hashCode(); }
}
