package javazik.model.media;

import javazik.model.Descriptible;
import javazik.model.Playable;
import javazik.model.review.AvisMorceau;

import java.io.Serial;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.UUID;

/**
 * Représente un morceau du catalogue musical.
 *
 * <p>Un morceau possède un interprète principal, peut appartenir à plusieurs albums
 * et agrège les statistiques utiles à l'application : nombre d'écoutes, avis et
 * nombre d'ajouts dans les playlists.</p>
 */
public class Morceau implements Serializable, Descriptible, Playable {
    @Serial
    private static final long serialVersionUID = 1L;

    private final String id;
    private final String titre;
    private final int dureeSecondes;
    private final Genre genre;
    private final int annee;
    private final EntiteArtistique interprete;
    private final List<Album> albums;
    private final List<AvisMorceau> avis;
    private int nombreEcoutes;
    private int nombreAjoutsPlaylists;

    public Morceau(String titre, int dureeSecondes, Genre genre, int annee, EntiteArtistique interprete) {
        this.id = UUID.randomUUID().toString();
        this.titre = Objects.requireNonNull(titre, "Le titre est obligatoire").trim();
        this.dureeSecondes = dureeSecondes;
        this.genre = Objects.requireNonNull(genre, "Le genre est obligatoire");
        this.annee = annee;
        this.interprete = Objects.requireNonNull(interprete, "L'interprète est obligatoire");
        this.albums = new ArrayList<>();
        this.avis = new ArrayList<>();
        this.nombreEcoutes = 0;
        this.nombreAjoutsPlaylists = 0;
    }

    public String getId() { return id; }
    public String getTitre() { return titre; }
    @Override public int getDureeSecondes() { return dureeSecondes; }
    public Genre getGenre() { return genre; }
    public int getAnnee() { return annee; }
    public EntiteArtistique getInterprete() { return interprete; }
    public List<Album> getAlbums() { return Collections.unmodifiableList(albums); }
    public int getNombreEcoutes() { return nombreEcoutes; }
    public List<AvisMorceau> getAvis() { return Collections.unmodifiableList(avis); }
    public int getNombreAjoutsPlaylists() { return nombreAjoutsPlaylists; }

    public double getNoteMoyenne() {
        if (avis.isEmpty()) {
            return 0.0;
        }
        int total = 0;
        for (AvisMorceau unAvis : avis) {
            total += unAvis.getNote();
        }
        return total / (double) avis.size();
    }

    public void ajouterAlbum(Album album) {
        if (album != null && !albums.contains(album)) {
            albums.add(album);
        }
    }

    public void retirerAlbum(Album album) {
        albums.remove(album);
    }

    public void incrementerEcoutes() {
        nombreEcoutes++;
    }

    public void incrementerAjoutsPlaylists() {
        nombreAjoutsPlaylists++;
    }

    public void ajouterOuMettreAJourAvis(String auteurIdentifiant, int note, String commentaire) {
        for (AvisMorceau avisMorceau : avis) {
            if (avisMorceau.getAuteurIdentifiant().equals(auteurIdentifiant)) {
                avisMorceau.mettreAJour(note, commentaire);
                return;
            }
        }
        avis.add(new AvisMorceau(auteurIdentifiant, note, commentaire));
    }

    public void supprimerAvis(String auteurIdentifiant) {
        avis.removeIf(a -> a.getAuteurIdentifiant().equals(auteurIdentifiant));
    }

    @Override
    public String getPlayLabel() {
        return titre + " — " + interprete.getNom();
    }

    @Override
    public String descriptionCourte() {
        return "Morceau - " + titre + " - " + interprete.getNom()
                + " [" + genre + ", " + annee + ", " + formatDuree(dureeSecondes) + "]";
    }

    @Override
    public String descriptionDetaillee() {
        StringBuilder sb = new StringBuilder(descriptionCourte());
        sb.append(System.lineSeparator()).append("Interprète : ").append(interprete.getNom());
        sb.append(System.lineSeparator()).append("Durée : ").append(formatDuree(dureeSecondes));
        sb.append(System.lineSeparator()).append("Écoutes : ").append(nombreEcoutes);
        sb.append(System.lineSeparator()).append("Ajouts en playlists : ").append(nombreAjoutsPlaylists);
        sb.append(System.lineSeparator()).append("Note moyenne : ")
                .append(String.format(Locale.US, "%.2f", getNoteMoyenne()));
        if (!albums.isEmpty()) {
            sb.append(System.lineSeparator()).append("Albums : ");
            for (int i = 0; i < albums.size(); i++) {
                if (i > 0) {
                    sb.append(", ");
                }
                sb.append(albums.get(i).getTitre());
            }
        }
        if (!avis.isEmpty()) {
            sb.append(System.lineSeparator()).append("Avis abonnés :");
            for (AvisMorceau unAvis : avis) {
                sb.append(System.lineSeparator()).append(" - ").append(unAvis);
            }
        }
        return sb.toString();
    }

    public static String formatDuree(int seconds) {
        int min = seconds / 60;
        int sec = seconds % 60;
        return String.format("%02d:%02d", min, sec);
    }

    @Override
    public String toString() {
        return descriptionCourte();
    }

    @Override
    public boolean equals(Object o) {
        if (!(o instanceof Morceau morceau)) {
            return false;
        }
        return id.equals(morceau.id);
    }

    @Override
    public int hashCode() {
        return id.hashCode();
    }
}
