package javazik.model.media;

/**
 * Modes de tri proposés dans la recherche avancée.
 */
public enum SongSortMode {
    TITRE("Titre"),
    ANNEE("Année"),
    DUREE("Durée"),
    ECOUTES("Nombre d'écoutes"),
    NOTE_MOYENNE("Note moyenne");

    private final String label;

    SongSortMode(String label) {
        this.label = label;
    }

    @Override
    public String toString() {
        return label;
    }
}
