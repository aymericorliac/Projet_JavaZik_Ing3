package javazik.model.playlist;

import javazik.model.Descriptible;
import javazik.model.media.Morceau;

import java.io.Serial;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.UUID;

/**
 * Playlist personnelle d'un abonné.
 */
public class Playlist implements Serializable, Descriptible {
    @Serial
    private static final long serialVersionUID = 1L;

    private final String id;
    private String nom;
    private final String proprietaireIdentifiant;
    private final List<Morceau> morceaux;

    public Playlist(String nom, String proprietaireIdentifiant) {
        this.id = UUID.randomUUID().toString();
        this.nom = Objects.requireNonNull(nom, "Nom obligatoire").trim();
        this.proprietaireIdentifiant = Objects.requireNonNull(proprietaireIdentifiant);
        this.morceaux = new ArrayList<>();
    }

    public String getId() { return id; }
    public String getNom() { return nom; }
    public String getProprietaireIdentifiant() { return proprietaireIdentifiant; }
    public List<Morceau> getMorceaux() { return Collections.unmodifiableList(morceaux); }

    public int getDureeTotaleSecondes() {
        return morceaux.stream().mapToInt(Morceau::getDureeSecondes).sum();
    }

    public void renommer(String nouveauNom) {
        this.nom = Objects.requireNonNull(nouveauNom, "Nom obligatoire").trim();
    }

    public boolean ajouterMorceau(Morceau morceau) {
        if (morceau != null && !morceaux.contains(morceau)) {
            boolean ajoute = morceaux.add(morceau);
            if (ajoute) {
                morceau.incrementerAjoutsPlaylists();
            }
            return ajoute;
        }
        return false;
    }

    public int ajouterDepuis(Playlist autre) {
        int count = 0;
        if (autre != null) {
            for (Morceau morceau : autre.getMorceaux()) {
                if (ajouterMorceau(morceau)) {
                    count++;
                }
            }
        }
        return count;
    }

    public boolean retirerMorceau(Morceau morceau) {
        return morceaux.remove(morceau);
    }

    @Override
    public String descriptionCourte() {
        return "Playlist - " + nom + " (" + morceaux.size() + " morceau(x), "
                + Morceau.formatDuree(getDureeTotaleSecondes()) + ")";
    }

    @Override
    public String descriptionDetaillee() {
        StringBuilder sb = new StringBuilder(descriptionCourte());
        for (Morceau morceau : morceaux) {
            sb.append(System.lineSeparator()).append(" - ").append(morceau.getPlayLabel());
        }
        return sb.toString();
    }

    @Override
    public String toString() {
        return descriptionCourte();
    }
}
