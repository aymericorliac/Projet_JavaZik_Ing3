package javazik.exception;

public class JavazikException extends Exception {
    public JavazikException(String message) { super(message); }
}
