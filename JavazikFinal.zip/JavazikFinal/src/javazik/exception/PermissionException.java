package javazik.exception;

public class PermissionException extends JavazikException {
    public PermissionException(String message) { super(message); }
}
