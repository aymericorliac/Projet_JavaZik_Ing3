package javazik.exception;

public class ValidationException extends JavazikException {
    public ValidationException(String message) { super(message); }
}
