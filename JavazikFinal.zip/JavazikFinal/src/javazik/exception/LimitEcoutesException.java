package javazik.exception;

public class LimitEcoutesException extends JavazikException {
    public LimitEcoutesException(String message) { super(message); }
}
