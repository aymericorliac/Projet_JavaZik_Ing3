package javazik.exception;

public class NotFoundException extends JavazikException {
    public NotFoundException(String message) { super(message); }
}
