package javazik.exception;

public class AuthenticationException extends JavazikException {
    public AuthenticationException(String message) { super(message); }
}
