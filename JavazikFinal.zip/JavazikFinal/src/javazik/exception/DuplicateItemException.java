package javazik.exception;

public class DuplicateItemException extends JavazikException {
    public DuplicateItemException(String message) { super(message); }
}
