package javazik.view.gui.components;

import javax.swing.BorderFactory;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.border.Border;
import java.awt.Color;
import java.awt.Font;

/**
 * Petite identité visuelle centralisée pour l'interface Swing.
 *
 * <p>Le thème cherche un rendu plus musical et chaleureux tout en restant
 * lisible pour une soutenance.</p>
 */
public final class Theme {
    public static final Color BG = new Color(245, 247, 252);
    public static final Color CARD = new Color(255, 255, 255);
    public static final Color PRIMARY = new Color(79, 70, 229);
    public static final Color ACCENT = new Color(14, 165, 233);
    public static final Color SUCCESS = new Color(22, 163, 74);
    public static final Color WARNING = new Color(245, 158, 11);
    public static final Color DANGER = new Color(220, 38, 38);
    public static final Color TEXT = new Color(17, 24, 39);
    public static final Color MUTED = new Color(100, 116, 139);
    public static final Color HERO = new Color(179, 179, 179, 255);
    public static final Color HERO_TEXT = new Color(15, 23, 42);
    public static final Color SOFT_PRIMARY = new Color(238, 242, 255);
    public static final Color SOFT_ACCENT = new Color(236, 254, 255);
    public static final Color SOFT_SUCCESS = new Color(240, 253, 244);
    public static final Font TITLE = new Font("SansSerif", Font.BOLD, 28);
    public static final Font SUBTITLE = new Font("SansSerif", Font.BOLD, 16);
    public static final Font BODY = new Font("SansSerif", Font.PLAIN, 13);

    private Theme() {
    }

    public static Border cardBorder(String title) {
        return BorderFactory.createCompoundBorder(
                BorderFactory.createTitledBorder(
                        BorderFactory.createLineBorder(new Color(203, 213, 225), 1, true),
                        title
                ),
                BorderFactory.createEmptyBorder(8, 8, 8, 8)
        );
    }

    public static JLabel title(String text) {
        JLabel label = new JLabel(text);
        label.setFont(TITLE);
        label.setForeground(TEXT);
        return label;
    }

    public static void applyCard(JComponent component) {
        component.setBackground(CARD);
        component.setForeground(TEXT);
        component.setFont(BODY);
    }
}
