package javazik.view.gui.components;

import javazik.model.media.Album;
import javazik.model.media.EntiteArtistique;
import javazik.model.media.Morceau;
import javazik.model.playlist.Playlist;

import javax.swing.BorderFactory;
import javax.swing.DefaultListCellRenderer;
import javax.swing.JList;
import javax.swing.border.Border;
import java.awt.Color;
import java.awt.Component;

/**
 * Rendu uniforme et lisible pour les listes de l'interface graphique.
 */
public class MediaListCellRenderer extends DefaultListCellRenderer {
    @Override
    public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
        super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
        String text;
        if (value instanceof Morceau morceau) {
            text = morceau.getTitre() + "  •  " + morceau.getInterprete().getNom() + "  •  " + morceau.getGenre();
        } else if (value instanceof Album album) {
            text = album.getTitre() + " (" + album.getAnnee() + ")  •  " + album.getArtiste().getNom();
        } else if (value instanceof EntiteArtistique entite) {
            text = entite.getTypeLabel() + "  •  " + entite.getNom() + "  •  " + entite.getPays();
        } else if (value instanceof Playlist playlist) {
            text = playlist.getNom() + "  •  " + playlist.getMorceaux().size() + " morceau(x)";
        } else {
            text = String.valueOf(value);
        }
        setText(text);
        Border padding = BorderFactory.createEmptyBorder(6, 8, 6, 8);
        Border separator = BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(226, 232, 240));
        setBorder(BorderFactory.createCompoundBorder(separator, padding));
        setBackground(isSelected ? Theme.SOFT_PRIMARY : Theme.CARD);
        setForeground(Theme.TEXT);
        return this;
    }
}
