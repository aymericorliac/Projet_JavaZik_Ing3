package javazik.view.console;

import javazik.controller.AppController;
import javazik.exception.AuthenticationException;
import javazik.exception.JavazikException;
import javazik.model.core.StatistiquesSnapshot;
import javazik.model.media.Album;
import javazik.model.media.Artiste;
import javazik.model.media.EntiteArtistique;
import javazik.model.media.Genre;
import javazik.model.media.Groupe;
import javazik.model.media.Morceau;
import javazik.model.media.SongSortMode;
import javazik.model.playlist.Playlist;
import javazik.model.user.Utilisateur;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

/**
 * Vue console complète de l'application.
 *
 * <p>Cette version couvre intégralement les fonctionnalités de base du sujet,
 * puis expose les extensions retenues : recherche avancée, notes/avis,
 * recommandations et statistiques évoluées.</p>
 */
public class ConsoleApp {
    private final AppController controller;
    private final Scanner scanner;

    public ConsoleApp(AppController controller) {
        this.controller = controller;
        this.scanner = new Scanner(System.in);
    }

    public void run() {
        boolean continuer = true;
        while (continuer) {
            afficherTitrePrincipal();
            afficherSessionCourante();
            System.out.println("1. Se connecter en tant qu'administrateur");
            System.out.println("2. Se connecter en tant qu'abonné");
            System.out.println("3. Créer un compte abonné");
            System.out.println("4. Continuer en tant que visiteur");
            System.out.println("5. Sauvegarder");
            System.out.println("6. Quitter");
            int choix = lireInt("Votre choix : ");
            try {
                switch (choix) {
                    case 1 -> {
                        connecterAdmin();
                        boucleAdmin();
                    }
                    case 2 -> {
                        connecterAbonne();
                        boucleAbonne();
                    }
                    case 3 -> creerCompte();
                    case 4 -> {
                        controller.continuerCommeVisiteur();
                        boucleVisiteur();
                    }
                    case 5 -> {
                        controller.sauvegarder();
                        System.out.println("Sauvegarde effectuée.");
                        pause();
                    }
                    case 6 -> {
                        controller.sauvegarder();
                        continuer = false;
                    }
                    default -> messageErreur("Choix invalide.");
                }
            } catch (AuthenticationException e) {
                messageErreur(e.getMessage());
                pause();
            } catch (IOException e) {
                messageErreur("Erreur de sauvegarde : " + e.getMessage());
                continuer = false;
            }
        }
    }

    private void boucleVisiteur() {
        boolean retour = false;
        while (!retour) {
            afficherTitreSection("ESPACE VISITEUR");
            afficherSessionCourante();
            System.out.println("1. Parcourir le catalogue complet");
            System.out.println("2. Rechercher dans le catalogue");
            System.out.println("3. Recherche avancée (genre, année, tri)");
            System.out.println("4. Explorer un album");
            System.out.println("5. Explorer un artiste ou un groupe");
            System.out.println("6. Écouter un morceau");
            System.out.println("7. Voir les détails/navigation d'un morceau");
            System.out.println("8. Retour au menu principal");
            switch (lireInt("Votre choix : ")) {
                case 1 -> consulterCatalogue();
                case 2 -> rechercherCatalogue();
                case 3 -> rechercheAvancee();
                case 4 -> explorerAlbum();
                case 5 -> explorerEntiteArtistique();
                case 6 -> ecouterMorceau();
                case 7 -> detailsMorceau();
                case 8 -> retour = true;
                default -> messageErreur("Choix invalide.");
            }
            if (!retour) pause();
        }
        controller.deconnecter();
    }

    private void boucleAbonne() {
        boolean retour = false;
        while (!retour) {
            afficherTitreSection("ESPACE ABONNÉ");
            afficherSessionCourante();
            System.out.println("1. Parcourir le catalogue complet");
            System.out.println("2. Rechercher dans le catalogue");
            System.out.println("3. Recherche avancée (genre, année, tri)");
            System.out.println("4. Explorer un album");
            System.out.println("5. Explorer un artiste ou un groupe");
            System.out.println("6. Écouter un morceau");
            System.out.println("7. Voir les détails/navigation d'un morceau");
            System.out.println("8. Gérer mes playlists");
            System.out.println("9. Voir mon historique d'écoute");
            System.out.println("10. Noter / commenter un morceau");
            System.out.println("11. Supprimer mon avis sur un morceau");
            System.out.println("12. Voir mes recommandations");
            System.out.println("13. Sauvegarder");
            System.out.println("14. Retour au menu principal");
            switch (lireInt("Votre choix : ")) {
                case 1 -> consulterCatalogue();
                case 2 -> rechercherCatalogue();
                case 3 -> rechercheAvancee();
                case 4 -> explorerAlbum();
                case 5 -> explorerEntiteArtistique();
                case 6 -> ecouterMorceau();
                case 7 -> detailsMorceau();
                case 8 -> bouclePlaylists();
                case 9 -> afficherHistorique();
                case 10 -> noterMorceau();
                case 11 -> supprimerAvis();
                case 12 -> afficherRecommandations();
                case 13 -> sauvegarderSilencieusement();
                case 14 -> retour = true;
                default -> messageErreur("Choix invalide.");
            }
            if (!retour) pause();
        }
        controller.deconnecter();
    }

    private void boucleAdmin() {
        boolean retour = false;
        while (!retour) {
            afficherTitreSection("ESPACE ADMINISTRATEUR");
            afficherSessionCourante();
            System.out.println("1. Parcourir le catalogue complet");
            System.out.println("2. Rechercher dans le catalogue");
            System.out.println("3. Recherche avancée (genre, année, tri)");
            System.out.println("4. Ajouter un artiste");
            System.out.println("5. Ajouter un groupe");
            System.out.println("6. Lier un artiste à un groupe");
            System.out.println("7. Ajouter un album");
            System.out.println("8. Ajouter un morceau");
            System.out.println("9. Supprimer un morceau");
            System.out.println("10. Supprimer un album");
            System.out.println("11. Supprimer un artiste / groupe");
            System.out.println("12. Suspendre un abonné");
            System.out.println("13. Réactiver un abonné");
            System.out.println("14. Supprimer un abonné");
            System.out.println("15. Lister les comptes");
            System.out.println("16. Voir les statistiques complètes");
            System.out.println("17. Sauvegarder");
            System.out.println("18. Retour au menu principal");
            try {
                switch (lireInt("Votre choix : ")) {
                    case 1 -> consulterCatalogue();
                    case 2 -> rechercherCatalogue();
                    case 3 -> rechercheAvancee();
                    case 4 -> ajouterArtisteAdmin();
                    case 5 -> ajouterGroupeAdmin();
                    case 6 -> lierArtisteAuGroupeAdmin();
                    case 7 -> ajouterAlbumAdmin();
                    case 8 -> ajouterMorceauAdmin();
                    case 9 -> supprimerMorceauAdmin();
                    case 10 -> supprimerAlbumAdmin();
                    case 11 -> supprimerEntiteAdmin();
                    case 12 -> controller.suspendreAbonne(lireTexte("Identifiant abonné à suspendre : "));
                    case 13 -> controller.reactiverAbonne(lireTexte("Identifiant abonné à réactiver : "));
                    case 14 -> controller.supprimerAbonne(lireTexte("Identifiant abonné à supprimer : "));
                    case 15 -> afficherListe(controller.getUtilisateurs());
                    case 16 -> afficherStatistiques();
                    case 17 -> sauvegarderSilencieusement();
                    case 18 -> retour = true;
                    default -> messageErreur("Choix invalide.");
                }
            } catch (JavazikException e) {
                messageErreur(e.getMessage());
            }
            if (!retour) pause();
        }
        controller.deconnecter();
    }

    private void bouclePlaylists() {
        boolean retour = false;
        while (!retour) {
            afficherTitreSection("GESTION DES PLAYLISTS");
            afficherListe(controller.getPlaylistsCourantes());
            System.out.println("1. Créer une playlist");
            System.out.println("2. Renommer une playlist");
            System.out.println("3. Supprimer une playlist");
            System.out.println("4. Afficher le contenu d'une playlist");
            System.out.println("5. Ajouter un morceau à une playlist");
            System.out.println("6. Retirer un morceau d'une playlist");
            System.out.println("7. Copier les morceaux d'une playlist vers une autre");
            System.out.println("8. Retour");
            try {
                switch (lireInt("Votre choix : ")) {
                    case 1 -> controller.creerPlaylist(lireTexte("Nom de la playlist : "));
                    case 2 -> {
                        Playlist playlist = choisirPlaylist();
                        if (playlist != null) {
                            controller.renommerPlaylist(playlist.getId(), lireTexte("Nouveau nom : "));
                        }
                    }
                    case 3 -> {
                        Playlist playlist = choisirPlaylist();
                        if (playlist != null) {
                            controller.supprimerPlaylist(playlist.getId());
                        }
                    }
                    case 4 -> afficherContenuPlaylist();
                    case 5 -> ajouterMorceauAPlaylist();
                    case 6 -> retirerMorceauDePlaylist();
                    case 7 -> copierPlaylistVersPlaylist();
                    case 8 -> retour = true;
                    default -> messageErreur("Choix invalide.");
                }
            } catch (JavazikException e) {
                messageErreur(e.getMessage());
            }
            if (!retour) pause();
        }
    }

    private void consulterCatalogue() {
        afficherTitreSection("CATALOGUE COMPLET");
        System.out.println("MORCEAUX");
        afficherListe(controller.getCatalogue().getMorceaux());
        System.out.println();
        System.out.println("ALBUMS");
        afficherListe(controller.getCatalogue().getAlbums());
        System.out.println();
        System.out.println("ARTISTES ET GROUPES");
        afficherListe(controller.getCatalogue().getEntitesArtistiques());
    }

    private void rechercherCatalogue() {
        afficherTitreSection("RECHERCHE SIMPLE");
        String texte = lireTexte("Texte à rechercher : ");
        System.out.println("Résultats morceaux :");
        afficherListe(controller.rechercherMorceaux(texte));
        System.out.println("Résultats albums :");
        afficherListe(controller.rechercherAlbums(texte));
        System.out.println("Résultats artistes / groupes :");
        afficherListe(controller.rechercherArtistesOuGroupes(texte));
    }

    private void rechercheAvancee() {
        afficherTitreSection("RECHERCHE AVANCÉE");
        String texte = lireTexte("Texte : ");
        Genre genre = lireGenreOptionnel();
        Integer anneeMin = lireEntierOptionnel("Année minimum (vide si aucune) : ");
        Integer anneeMax = lireEntierOptionnel("Année maximum (vide si aucune) : ");
        SongSortMode tri = lireTriOptionnel();
        afficherListe(controller.rechercheAvancee(texte, genre, anneeMin, anneeMax, tri));
    }

    private void explorerAlbum() {
        afficherTitreSection("EXPLORATION D'ALBUM");
        Album album = choisirAlbum();
        if (album == null) {
            return;
        }
        System.out.println(album.descriptionDetaillee());
        System.out.println();
        System.out.println("Morceaux de l'album :");
        afficherListe(controller.getMorceauxParAlbum(album));
    }

    private void explorerEntiteArtistique() {
        afficherTitreSection("EXPLORATION D'ARTISTE / GROUPE");
        EntiteArtistique entite = choisirEntite();
        if (entite == null) {
            return;
        }
        System.out.println(entite.descriptionDetaillee());
        System.out.println();
        System.out.println("Albums :");
        afficherListe(controller.getAlbumsParEntite(entite));
        System.out.println("Morceaux :");
        afficherListe(controller.getMorceauxParEntite(entite));
    }

    private void ecouterMorceau() {
        try {
            Morceau morceau = choisirMorceau();
            if (morceau == null) {
                return;
            }
            controller.ecouterMorceau(morceau);
            System.out.println("Lecture simulée : " + morceau.getPlayLabel());
            int total = 20;
            for (int i = 0; i <= total; i++) {
                try {
                    Thread.sleep(55);
                } catch (InterruptedException ignored) {
                    Thread.currentThread().interrupt();
                }
                int progress = i * 100 / total;
                String bar = "#".repeat(i) + "-".repeat(total - i);
                System.out.print("\r[" + bar + "] " + progress + "%");
            }
            System.out.println();
        } catch (JavazikException e) {
            messageErreur(e.getMessage());
        }
    }

    private void detailsMorceau() {
        afficherTitreSection("DÉTAILS / NAVIGATION");
        Morceau morceau = choisirMorceau();
        if (morceau != null) {
            System.out.println(controller.detailsNavigation(morceau));
        }
    }

    private void afficherHistorique() {
        afficherTitreSection("HISTORIQUE D'ÉCOUTE");
        afficherListe(controller.getHistoriqueCourant());
    }

    private void afficherRecommandations() {
        afficherTitreSection("RECOMMANDATIONS");
        afficherListe(controller.getRecommendationsCourantes());
    }

    private void noterMorceau() {
        afficherTitreSection("NOTATION ET AVIS");
        try {
            Morceau morceau = choisirMorceau();
            if (morceau != null) {
                int note = lireInt("Note de 1 à 5 : ");
                String commentaire = lireTexte("Commentaire : ");
                controller.noterMorceau(morceau, note, commentaire);
                System.out.println("Avis enregistré.");
            }
        } catch (JavazikException e) {
            messageErreur(e.getMessage());
        }
    }

    private void supprimerAvis() {
        afficherTitreSection("SUPPRESSION D'AVIS");
        try {
            Morceau morceau = choisirMorceau();
            if (morceau != null) {
                controller.supprimerAvis(morceau);
                System.out.println("Avis supprimé si présent.");
            }
        } catch (JavazikException e) {
            messageErreur(e.getMessage());
        }
    }

    private void afficherContenuPlaylist() {
        Playlist playlist = choisirPlaylist();
        if (playlist != null) {
            System.out.println(playlist.descriptionDetaillee());
        }
    }

    private void ajouterMorceauAPlaylist() throws JavazikException {
        Playlist playlist = choisirPlaylist();
        if (playlist == null) {
            return;
        }
        System.out.println("Choisissez la source du morceau :");
        System.out.println("1. Depuis le catalogue");
        System.out.println("2. Depuis une autre playlist");
        int choix = lireInt("Votre choix : ");
        Morceau morceau = null;
        if (choix == 1) {
            morceau = choisirMorceau();
        } else if (choix == 2) {
            Playlist source = choisirPlaylist();
            if (source != null) {
                morceau = choisirMorceauDansListe(source.getMorceaux(), "Index du morceau source : ");
            }
        }
        if (morceau != null) {
            controller.ajouterMorceauAPlaylist(playlist.getId(), morceau);
            System.out.println("Morceau ajouté.");
        }
    }

    private void retirerMorceauDePlaylist() throws JavazikException {
        Playlist playlist = choisirPlaylist();
        if (playlist == null) {
            return;
        }
        Morceau morceau = choisirMorceauDansListe(playlist.getMorceaux(), "Index du morceau à retirer : ");
        if (morceau != null) {
            controller.retirerMorceauDePlaylist(playlist.getId(), morceau);
            System.out.println("Morceau retiré.");
        }
    }

    private void copierPlaylistVersPlaylist() throws JavazikException {
        System.out.println("Playlist cible :");
        Playlist cible = choisirPlaylist();
        System.out.println("Playlist source :");
        Playlist source = choisirPlaylist();
        if (cible != null && source != null) {
            int ajouts = controller.ajouterDepuisAutrePlaylist(cible.getId(), source.getId());
            System.out.println(ajouts + " morceau(x) ajouté(s).");
        }
    }

    private void ajouterArtisteAdmin() throws JavazikException {
        controller.ajouterArtiste(lireTexte("Nom artiste : "), lireTexte("Pays : "));
        System.out.println("Artiste ajouté.");
    }

    private void ajouterGroupeAdmin() throws JavazikException {
        controller.ajouterGroupe(lireTexte("Nom groupe : "), lireTexte("Pays : "));
        System.out.println("Groupe ajouté.");
    }

    private void lierArtisteAuGroupeAdmin() throws JavazikException {
        Artiste artiste = choisirArtiste();
        Groupe groupe = choisirGroupe();
        if (artiste != null && groupe != null) {
            controller.lierArtisteAuGroupe(groupe, artiste);
            System.out.println("Liaison créée.");
        }
    }

    private void ajouterAlbumAdmin() throws JavazikException {
        EntiteArtistique entite = choisirEntite();
        if (entite != null) {
            controller.ajouterAlbum(lireTexte("Titre album : "), lireInt("Année : "), entite);
            System.out.println("Album ajouté.");
        }
    }

    private void ajouterMorceauAdmin() throws JavazikException {
        EntiteArtistique entite = choisirEntite();
        if (entite == null) {
            return;
        }
        String titre = lireTexte("Titre morceau : ");
        int duree = lireInt("Durée réelle du morceau en secondes : ");
        System.out.println("La lecture graphique reste simulée sur 20 secondes.");
        int annee = lireInt("Année : ");
        Genre genre = lireGenreObligatoire();
        List<Album> albumsAssocies = choisirPlusieursAlbums();
        controller.ajouterMorceau(titre, duree, genre, annee, entite, albumsAssocies);
        System.out.println("Morceau ajouté.");
    }

    private void supprimerMorceauAdmin() throws JavazikException {
        Morceau morceau = choisirMorceau();
        if (morceau != null) {
            controller.supprimerMorceau(morceau.getId());
            System.out.println("Morceau supprimé.");
        }
    }

    private void supprimerAlbumAdmin() throws JavazikException {
        Album album = choisirAlbum();
        if (album != null) {
            controller.supprimerAlbum(album.getId());
            System.out.println("Album supprimé.");
        }
    }

    private void supprimerEntiteAdmin() throws JavazikException {
        EntiteArtistique entite = choisirEntite();
        if (entite != null) {
            controller.supprimerEntiteArtistique(entite.getId());
            System.out.println("Artiste / groupe supprimé.");
        }
    }

    private void afficherStatistiques() throws JavazikException {
        afficherTitreSection("STATISTIQUES SIMPLES ET ÉVOLUÉES");
        StatistiquesSnapshot snapshot = controller.getStatistiques();
        System.out.println(snapshot);
    }

    private void sauvegarderSilencieusement() {
        try {
            controller.sauvegarder();
            System.out.println("Sauvegarde effectuée.");
        } catch (IOException e) {
            messageErreur("Impossible de sauvegarder : " + e.getMessage());
        }
    }

    private void connecterAdmin() throws AuthenticationException {
        controller.connecterAdmin(lireTexte("Identifiant admin : "), lireTexte("Mot de passe : "));
    }

    private void connecterAbonne() throws AuthenticationException {
        controller.connecterAbonne(lireTexte("Identifiant abonné : "), lireTexte("Mot de passe : "));
    }

    private void creerCompte() {
        try {
            controller.creerCompte(
                    lireTexte("Nouvel identifiant : "),
                    lireTexte("Mot de passe : "),
                    lireTexte("Nom affiché : ")
            );
            System.out.println("Compte créé avec succès.");
        } catch (JavazikException e) {
            messageErreur(e.getMessage());
        }
        pause();
    }

    private Morceau choisirMorceau() {
        return choisirMorceauDansListe(controller.getCatalogue().getMorceaux(), "Index du morceau : ");
    }

    private Morceau choisirMorceauDansListe(List<Morceau> morceaux, String message) {
        afficherListe(morceaux);
        if (morceaux.isEmpty()) {
            return null;
        }
        int index = lireInt(message);
        return index >= 0 && index < morceaux.size() ? morceaux.get(index) : null;
    }

    private Playlist choisirPlaylist() {
        List<Playlist> playlists = controller.getPlaylistsCourantes();
        afficherListe(playlists);
        if (playlists.isEmpty()) {
            return null;
        }
        int index = lireInt("Index playlist : ");
        return index >= 0 && index < playlists.size() ? playlists.get(index) : null;
    }

    private Album choisirAlbum() {
        List<Album> albums = controller.getCatalogue().getAlbums();
        afficherListe(albums);
        if (albums.isEmpty()) {
            return null;
        }
        int index = lireInt("Index album : ");
        return index >= 0 && index < albums.size() ? albums.get(index) : null;
    }

    private EntiteArtistique choisirEntite() {
        List<EntiteArtistique> entites = controller.getCatalogue().getEntitesArtistiques();
        afficherListe(entites);
        if (entites.isEmpty()) {
            return null;
        }
        int index = lireInt("Index artiste / groupe : ");
        return index >= 0 && index < entites.size() ? entites.get(index) : null;
    }

    private Artiste choisirArtiste() {
        List<Artiste> artistes = controller.getCatalogue().getArtistes();
        afficherListe(artistes);
        if (artistes.isEmpty()) {
            return null;
        }
        int index = lireInt("Index artiste : ");
        return index >= 0 && index < artistes.size() ? artistes.get(index) : null;
    }

    private Groupe choisirGroupe() {
        List<Groupe> groupes = controller.getCatalogue().getGroupes();
        afficherListe(groupes);
        if (groupes.isEmpty()) {
            return null;
        }
        int index = lireInt("Index groupe : ");
        return index >= 0 && index < groupes.size() ? groupes.get(index) : null;
    }

    private List<Album> choisirPlusieursAlbums() {
        List<Album> albums = controller.getCatalogue().getAlbums();
        if (albums.isEmpty()) {
            return List.of();
        }
        afficherListe(albums);
        String texte = lireTexte("Index d'albums séparés par des virgules (vide si aucun) : ");
        if (texte.isBlank()) {
            return List.of();
        }
        List<Album> selection = new ArrayList<>();
        for (String part : texte.split(",")) {
            try {
                int idx = Integer.parseInt(part.trim());
                if (idx >= 0 && idx < albums.size()) {
                    selection.add(albums.get(idx));
                }
            } catch (NumberFormatException ignored) {
                // On ignore proprement les valeurs invalides.
            }
        }
        return selection;
    }

    private Genre lireGenreObligatoire() {
        while (true) {
            try {
                return Genre.valueOf(lireTexte("Genre " + Arrays.toString(Genre.values()) + " : ").trim().toUpperCase());
            } catch (IllegalArgumentException e) {
                messageErreur("Genre invalide.");
            }
        }
    }

    private Genre lireGenreOptionnel() {
        while (true) {
            String texte = lireTexte("Genre (vide ou " + Arrays.toString(Genre.values()) + ") : ");
            if (texte.isBlank()) {
                return null;
            }
            try {
                return Genre.valueOf(texte.trim().toUpperCase());
            } catch (IllegalArgumentException e) {
                messageErreur("Genre invalide.");
            }
        }
    }

    private SongSortMode lireTriOptionnel() {
        while (true) {
            String texte = lireTexte("Tri (vide ou " + Arrays.toString(SongSortMode.values()) + ") : ");
            if (texte.isBlank()) {
                return SongSortMode.TITRE;
            }
            try {
                return SongSortMode.valueOf(texte.trim().toUpperCase());
            } catch (IllegalArgumentException e) {
                messageErreur("Mode de tri invalide.");
            }
        }
    }

    private Integer lireEntierOptionnel(String message) {
        while (true) {
            String texte = lireTexte(message);
            if (texte.isBlank()) {
                return null;
            }
            try {
                return Integer.parseInt(texte);
            } catch (NumberFormatException e) {
                messageErreur("Veuillez saisir un entier ou laisser vide.");
            }
        }
    }

    private void afficherListe(List<?> liste) {
        if (liste == null || liste.isEmpty()) {
            System.out.println("(aucun résultat)");
            return;
        }
        for (int i = 0; i < liste.size(); i++) {
            System.out.println("[" + i + "] " + liste.get(i));
        }
    }

    private void afficherTitrePrincipal() {
        System.out.println();
        System.out.println("╔══════════════════════════════════════════════════════════════════════╗");
        System.out.println("║                          JAVAZIK - CONSOLE                         ║");
        System.out.println("║    Catalogue musical, playlists, administration et statistiques    ║");
        System.out.println("╚══════════════════════════════════════════════════════════════════════╝");
    }

    private void afficherTitreSection(String titre) {
        System.out.println();
        System.out.println("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
        System.out.println("  " + titre);
        System.out.println("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
    }

    private void afficherSessionCourante() {
        System.out.println("Session courante : " + controller.getSession());
    }

    private void messageErreur(String message) {
        System.out.println("[ERREUR] " + message);
    }

    private String lireTexte(String message) {
        System.out.print(message);
        return scanner.nextLine().trim();
    }

    private int lireInt(String message) {
        while (true) {
            try {
                return Integer.parseInt(lireTexte(message));
            } catch (NumberFormatException e) {
                messageErreur("Veuillez entrer un entier valide.");
            }
        }
    }

    private void pause() {
        System.out.print("Appuyez sur Entrée pour continuer...");
        scanner.nextLine();
    }
}
