package javazik;

import javazik.controller.AppController;
import javazik.model.core.DemoDataFactory;
import javazik.model.core.PlateformeMusicale;
import javazik.persistence.PersistenceManager;
import javazik.view.console.ConsoleApp;
import javazik.view.gui.MainFrame;

import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import java.io.IOException;

/**
 * Point d'entrée unique de l'application.
 */
public final class Main {
    private static final String DATA_FILE = "data/javazik_polish_v2.ser";

    private Main() {
    }

    public static void main(String[] args) {
        PlateformeMusicale plateforme = PersistenceManager.loadOrCreate(DATA_FILE);
        DemoDataFactory.initializeIfEmpty(plateforme);
        AppController controller = new AppController(plateforme, DATA_FILE);

        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            try {
                controller.sauvegarder();
            } catch (IOException e) {
                System.err.println("Sauvegarde automatique impossible : " + e.getMessage());
            }
        }));

        String mode = args.length == 0 ? "gui" : args[0].trim().toLowerCase();
        if ("console".equals(mode)) {
            new ConsoleApp(controller).run();
        } else {
            initialiserLookAndFeel();
            SwingUtilities.invokeLater(() -> new MainFrame(controller).setVisible(true));
        }
    }

    private static void initialiserLookAndFeel() {
        try {
            for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    UIManager.setLookAndFeel(info.getClassName());
                    return;
                }
            }
        } catch (Exception ignored) {
            // Le look and feel par défaut sera utilisé si Nimbus n'est pas disponible.
        }
    }
}
