package javazik.persistence;

import javazik.model.core.PlateformeMusicale;

import java.io.*;

public final class PersistenceManager {
    private PersistenceManager() {}

    public static PlateformeMusicale loadOrCreate(String path) {
        File file = new File(path);
        if (!file.exists()) return new PlateformeMusicale();
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(file))) {
            Object object = ois.readObject();
            if (object instanceof PlateformeMusicale plateformeMusicale) return plateformeMusicale;
        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Chargement impossible, nouvelle base utilisée : " + e.getMessage());
        }
        return new PlateformeMusicale();
    }

    public static void save(PlateformeMusicale plateforme, String path) throws IOException {
        File file = new File(path);
        File parent = file.getParentFile();
        if (parent != null && !parent.exists()) parent.mkdirs();
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(file))) {
            oos.writeObject(plateforme);
        }
    }
}
