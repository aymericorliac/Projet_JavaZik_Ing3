package javazik.controller;

import javazik.exception.AuthenticationException;
import javazik.exception.JavazikException;
import javazik.exception.PermissionException;
import javazik.model.core.Catalogue;
import javazik.model.core.PlateformeMusicale;
import javazik.model.core.StatistiquesSnapshot;
import javazik.model.media.Album;
import javazik.model.media.Artiste;
import javazik.model.media.EntiteArtistique;
import javazik.model.media.Genre;
import javazik.model.media.Groupe;
import javazik.model.media.Morceau;
import javazik.model.media.SongSortMode;
import javazik.model.playlist.Playlist;
import javazik.model.session.SessionContext;
import javazik.model.user.Abonne;
import javazik.model.user.Administrateur;
import javazik.model.user.Utilisateur;
import javazik.persistence.PersistenceManager;

import java.io.IOException;
import java.util.Collections;
import java.util.List;

/**
 * Contrôleur principal entre le modèle et les vues.
 */
public class AppController {
    private final PlateformeMusicale modele;
    private final SessionContext session;
    private final String persistencePath;

    public AppController(PlateformeMusicale modele, String persistencePath) {
        this.modele = modele;
        this.persistencePath = persistencePath;
        this.session = new SessionContext();
        this.session.demarrerVisiteur();
    }

    public PlateformeMusicale getModele() { return modele; }
    public SessionContext getSession() { return session; }
    public Catalogue getCatalogue() { return modele.getCatalogue(); }

    public void continuerCommeVisiteur() { session.demarrerVisiteur(); }
    public void connecterAbonne(String identifiant, String motDePasse) throws AuthenticationException { session.connecter(modele.authentifierAbonne(identifiant, motDePasse)); }
    public void connecterAdmin(String identifiant, String motDePasse) throws AuthenticationException { session.connecter(modele.authentifierAdmin(identifiant, motDePasse)); }
    public Abonne creerCompte(String identifiant, String motDePasse, String nomAffichage) throws JavazikException {
        return modele.creerCompteAbonne(identifiant, motDePasse, nomAffichage);
    }
    public void deconnecter() { session.logout(); }

    public List<Morceau> rechercherMorceaux(String query) { return modele.rechercherMorceaux(query); }
    public List<Album> rechercherAlbums(String query) { return modele.rechercherAlbums(query); }
    public List<EntiteArtistique> rechercherArtistesOuGroupes(String query) { return modele.rechercherEntitesArtistiques(query); }
    public List<Morceau> rechercheAvancee(String query, Genre genre, Integer anneeMin, Integer anneeMax, SongSortMode sortMode) {
        return modele.rechercheAvanceeMorceaux(query, genre, anneeMin, anneeMax, sortMode);
    }
    public List<Morceau> getMorceauxParEntite(EntiteArtistique entite) { return modele.getCatalogue().getMorceauxParEntite(entite); }
    public List<Album> getAlbumsParEntite(EntiteArtistique entite) { return modele.getCatalogue().getAlbumsParEntite(entite); }
    public List<Morceau> getMorceauxParAlbum(Album album) { return modele.getCatalogue().getMorceauxParAlbum(album); }

    public void ecouterMorceau(Morceau morceau) throws JavazikException { modele.ecouterMorceau(session, morceau); }
    public String detailsNavigation(Morceau morceau) { return modele.getDetailsNavigation(morceau); }
    public Abonne getAbonneCourant() { return session.getAbonne(); }
    public Administrateur getAdminCourant() { return session.getAdmin(); }
    public List<Playlist> getPlaylistsCourantes() { return getAbonneCourant() == null ? Collections.emptyList() : getAbonneCourant().getPlaylists(); }
    public List<Morceau> getHistoriqueCourant() { return getAbonneCourant() == null ? Collections.emptyList() : getAbonneCourant().getHistoriqueEcoutes(); }
    public List<Morceau> getRecommendationsCourantes() { return getAbonneCourant() == null ? Collections.emptyList() : modele.recommanderPour(getAbonneCourant(), 8); }

    public void noterMorceau(Morceau morceau, int note, String commentaire) throws JavazikException {
        Abonne abonne = getAbonneCourant();
        if (abonne == null) throw new PermissionException("Seuls les abonnés peuvent noter un morceau.");
        modele.noterMorceau(abonne, morceau, note, commentaire);
    }

    public void supprimerAvis(Morceau morceau) throws JavazikException {
        Abonne abonne = getAbonneCourant();
        if (abonne == null) throw new PermissionException("Seuls les abonnés peuvent supprimer leur avis.");
        modele.supprimerAvis(abonne, morceau);
    }

    public Playlist creerPlaylist(String nom) throws JavazikException {
        Abonne abonne = getAbonneCourant();
        if (abonne == null) throw new PermissionException("Seuls les abonnés peuvent créer des playlists.");
        return modele.creerPlaylist(abonne, nom);
    }

    public void renommerPlaylist(String playlistId, String nouveauNom) throws JavazikException {
        Abonne abonne = getAbonneCourant();
        if (abonne == null) throw new PermissionException("Seuls les abonnés peuvent renommer des playlists.");
        modele.renommerPlaylist(abonne, playlistId, nouveauNom);
    }

    public void supprimerPlaylist(String playlistId) throws JavazikException {
        Abonne abonne = getAbonneCourant();
        if (abonne == null) throw new PermissionException("Seuls les abonnés peuvent supprimer des playlists.");
        modele.supprimerPlaylist(abonne, playlistId);
    }

    public void ajouterMorceauAPlaylist(String playlistId, Morceau morceau) throws JavazikException {
        Abonne abonne = getAbonneCourant();
        if (abonne == null) throw new PermissionException("Seuls les abonnés peuvent modifier des playlists.");
        modele.ajouterMorceauAPlaylist(abonne, playlistId, morceau);
    }

    public int ajouterDepuisAutrePlaylist(String cibleId, String sourceId) throws JavazikException {
        Abonne abonne = getAbonneCourant();
        if (abonne == null) throw new PermissionException("Seuls les abonnés peuvent modifier des playlists.");
        return modele.ajouterDepuisAutrePlaylist(abonne, cibleId, sourceId);
    }

    public void retirerMorceauDePlaylist(String playlistId, Morceau morceau) throws JavazikException {
        Abonne abonne = getAbonneCourant();
        if (abonne == null) throw new PermissionException("Seuls les abonnés peuvent modifier des playlists.");
        modele.retirerMorceauDePlaylist(abonne, playlistId, morceau);
    }

    public Artiste ajouterArtiste(String nom, String pays) throws JavazikException { exigerAdmin(); return modele.ajouterArtiste(nom, pays); }
    public Groupe ajouterGroupe(String nom, String pays) throws JavazikException { exigerAdmin(); return modele.ajouterGroupe(nom, pays); }
    public void lierArtisteAuGroupe(Groupe groupe, Artiste artiste) throws JavazikException { exigerAdmin(); modele.lierArtisteAuGroupe(groupe, artiste); }
    public Album ajouterAlbum(String titre, int annee, EntiteArtistique artiste) throws JavazikException { exigerAdmin(); return modele.ajouterAlbum(titre, annee, artiste); }
    public Morceau ajouterMorceau(String titre, int dureeSecondes, Genre genre, int annee, EntiteArtistique artiste, List<Album> albumsAssocies) throws JavazikException {
        exigerAdmin();
        return modele.ajouterMorceau(titre, dureeSecondes, genre, annee, artiste, albumsAssocies);
    }
    public void supprimerMorceau(String morceauId) throws JavazikException { exigerAdmin(); modele.supprimerMorceau(morceauId); }
    public void supprimerAlbum(String albumId) throws JavazikException { exigerAdmin(); modele.supprimerAlbum(albumId); }
    public void supprimerEntiteArtistique(String entiteId) throws JavazikException { exigerAdmin(); modele.supprimerEntiteArtistique(entiteId); }
    public void suspendreAbonne(String identifiant) throws JavazikException { exigerAdmin(); modele.suspendreCompteAbonne(identifiant); }
    public void reactiverAbonne(String identifiant) throws JavazikException { exigerAdmin(); modele.reactiverCompteAbonne(identifiant); }
    public void supprimerAbonne(String identifiant) throws JavazikException { exigerAdmin(); modele.supprimerCompteAbonne(identifiant); }

    public StatistiquesSnapshot getStatistiques() throws PermissionException { exigerAdmin(); return modele.getStatistiques(); }
    public List<Utilisateur> getUtilisateurs() throws PermissionException { exigerAdmin(); return modele.getUtilisateurs(); }

    private void exigerAdmin() throws PermissionException {
        if (getAdminCourant() == null) throw new PermissionException("Action réservée aux administrateurs.");
    }

    public void sauvegarder() throws IOException { PersistenceManager.save(modele, persistencePath); }
    public Playlist getPlaylistById(String playlistId) { return getAbonneCourant() == null ? null : getAbonneCourant().getPlaylistParId(playlistId); }
    public Morceau getMorceauById(String id) { return modele.getCatalogue().getMorceauById(id); }
    public Album getAlbumById(String id) { return modele.getCatalogue().getAlbumById(id); }
    public EntiteArtistique getEntiteById(String id) { return modele.getCatalogue().getEntiteArtistiqueById(id); }
}
