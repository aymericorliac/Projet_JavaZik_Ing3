# JAVAZIK – Projet POO Java

Projet complet de gestion d'un catalogue musical et de playlists, développé en Java selon une architecture **MVC** avec :
- une **version console intégrale** ;
- une **version graphique Swing** ;
- la **persistance par sérialisation** ;
- la gestion des rôles **visiteur / abonné / administrateur** ;
- des **extensions** : notes/avis, recommandations, recherche avancée, statistiques évoluées.

## Comptes de démonstration
- **admin / admin123**
- **alice / alice123**
- **bob / bob123**
- **charlie / charlie123**

## Jeu de données
Le catalogue de démonstration contient uniquement des artistes, groupes, albums et morceaux connus :
Queen, Adele, Coldplay, Daft Punk, Michael Jackson, Beyoncé, Ed Sheeran, Bruno Mars, Lady Gaga, The Beatles, ABBA et Imagine Dragons.

## Lancer le projet

### Depuis IntelliJ
1. Ouvrir le dossier du projet.
2. Vérifier que le JDK est configuré.
3. Exécuter `javazik.Main`.
4. Par défaut, l'application démarre en **mode graphique**.
5. Pour le **mode console**, ajouter l'argument de programme :
   ```text
   console
   ```

### Depuis un terminal
Compilation :
```bash
mkdir -p out
find src -name "*.java" > sources.txt
javac -encoding UTF-8 -d out @sources.txt
```

Lancement en mode graphique :
```bash
java -cp out javazik.Main
```

Lancement en mode console :
```bash
java -cp out javazik.Main console
```

### Générer un JAR exécutable
```bash
jar --create --file dist/JavazikExcellence.jar --main-class javazik.Main -C out .
```

### Générer la JavaDoc
```bash
javadoc -encoding UTF-8 -d javadoc $(find src -name "*.java")
```

## Structure du projet
- `src/javazik/model` : logique métier et données du système.
- `src/javazik/controller` : contrôleur MVC.
- `src/javazik/view/console` : vue console.
- `src/javazik/view/gui` : vue graphique Swing.
- `src/javazik/persistence` : sauvegarde / chargement.
- `src/javazik/exception` : exceptions métier.
- `docs` : éléments de rapport, UML, scénarios, storyboard, plan de tests.
- `data/javazik.ser` : base de données sérialisée.

## Fonctionnalités couvertes
### Visiteur
- consultation du catalogue ;
- recherche simple et avancée ;
- navigation morceaux / albums / artistes ;
- écoute simulée limitée à 5 morceaux par session ;
- lecteur simulé avec pause, reprise, avance, retour, piste suivante et précédente.

### Abonné
- toutes les fonctionnalités visiteur ;
- création, renommage et suppression de playlists ;
- ajout / retrait / copie de morceaux entre playlists ;
- historique d'écoute ;
- notation et commentaire de morceaux ;
- recommandations personnalisées.

### Administrateur
- ajout / suppression d'artistes, groupes, albums et morceaux ;
- liaison artiste ↔ groupe ;
- suspension, réactivation et suppression de comptes abonnés ;
- statistiques simples et évoluées.

## Conseils de démonstration pour la soutenance
1. Démarrer en **mode graphique**.
2. Montrer la consultation du catalogue en **visiteur**.
3. Montrer la limite d'écoute visiteur.
4. Se connecter en **abonné** puis :
   - créer une playlist ;
   - ajouter des morceaux ;
   - écouter ;
   - consulter l'historique ;
   - noter un morceau ;
   - afficher les recommandations.
5. Se connecter en **administrateur** puis :
   - ajouter un artiste ou un album ;
   - suspendre un abonné ;
   - afficher les statistiques.
6. Sauvegarder et relancer le projet pour prouver la persistance.
